Chrome Profile Switcher (modular)
Run: python main.py
Settings saved in %APPDATA%\ChromeProfileSwitcher\settings.json


v4.1 patch: Added Import/Export tab in Settings, no UI regressions; kept v4 layout and hotkey/overlay behavior.
