import tkinter as tk
from cps.settings import load_settings, save_settings
from cps.app import App
from cps.platform import IS_WINDOWS


import os
import sys
import socket
import threading


def resource_path(rel: str) -> str:
    """Return absolute path to resource for dev or PyInstaller."""
    if getattr(sys, 'frozen', False):
        return os.path.join(sys._MEIPASS, rel)  # type: ignore[attr-defined]
    return os.path.join(os.path.dirname(__file__), rel)


# ---------------- Single-instance (Windows-friendly, also works on other OSes) ----------------
# We use a localhost TCP listener. First instance binds; subsequent launches connect and ask the
# existing instance to show the main window, then exit immediately.
_SINGLE_INSTANCE_PORT = 48673  # fixed port for this app

def _try_start_single_instance_listener():
    """Return a bound listening socket, or None if another instance is already running."""
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        # Avoid TIME_WAIT surprises
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        # Bind only to loopback
        s.bind(("127.0.0.1", _SINGLE_INSTANCE_PORT))
        s.listen(5)
        return s
    except OSError:
        try:
            s.close()
        except Exception:
            pass
        return None

def _notify_existing_instance():
    """Tell an existing instance to show its window. Returns True if notified."""
    try:
        c = socket.create_connection(("127.0.0.1", _SINGLE_INSTANCE_PORT), timeout=0.5)
        try:
            c.sendall(b"SHOW\n")
        finally:
            c.close()
        return True
    except Exception:
        return False

def _start_ipc_server_thread(listen_sock: socket.socket, show_fn):
    """Start a daemon thread that waits for SHOW messages and calls show_fn() on the Tk thread."""
    def _run():
        while True:
            try:
                conn, _addr = listen_sock.accept()
            except Exception:
                break
            try:
                data = b""
                try:
                    data = conn.recv(32) or b""
                except Exception:
                    pass
                if b"SHOW" in data:
                    try:
                        show_fn()
                    except Exception:
                        pass
            finally:
                try:
                    conn.close()
                except Exception:
                    pass

    t = threading.Thread(target=_run, name="SingleInstanceIPC", daemon=True)
    t.start()
    return t


def main():
    # Single-instance: if another copy is running, ask it to show and exit.
    listen_sock = _try_start_single_instance_listener()
    if listen_sock is None:
        _notify_existing_instance()
        return

    settings = load_settings()

    root = tk.Tk()

    def _show_main_window_from_ipc():
        try:
            root.deiconify()
        except Exception:
            pass
        try:
            root.lift()
        except Exception:
            pass
        try:
            root.focus_force()
        except Exception:
            pass

    # Start IPC listener for subsequent launches
    _start_ipc_server_thread(listen_sock, lambda: root.after(0, _show_main_window_from_ipc))

    # App/window icon (also helps taskbar/Alt-Tab in many cases)
    try:
        root.iconbitmap(resource_path('assets/favicon.ico'))
    except Exception:
        pass


    root.title("Chrome Profile Switcher")

    app = App(root, settings)

    def on_close():
        # Persist window size/pos
        try:
            geo = root.winfo_geometry()  # e.g. 900x520+100+100
            size, x, y = geo.split("+", 2)
            w, h = size.split("x", 1)
            settings.setdefault("window", {})
            settings["window"]["width"] = int(w)
            settings["window"]["height"] = int(h)
            settings["window"]["x"] = int(x)
            settings["window"]["y"] = int(y)
        except Exception:
            pass

        # Persist any pending settings (favourites/recents etc)
        try:
            save_settings(settings)
        except Exception:
            pass

        # If tray is enabled and actually running, do NOT exit on X — hide to tray.
        try:
            tray_cfg = settings.get("tray") if isinstance(settings.get("tray"), dict) else {}
            tray_enabled = bool(tray_cfg.get("enabled", True)) if isinstance(tray_cfg, dict) else True
            tray_success = bool(getattr(app, "_tray_diag", {}).get("success")) if app is not None else False
            tray_mgr = getattr(app, "_tray_mgr", None)
            if tray_enabled and tray_success and tray_mgr is not None:
                try:
                    root.withdraw()
                except Exception:
                    pass
                return
        except Exception:
            pass

        # Otherwise close fully
        try:
            app.shutdown()
        except Exception:
            pass

        try:
            listen_sock.close()
        except Exception:
            pass

        root.destroy()


    root.protocol("WM_DELETE_WINDOW", on_close)

    # Apply saved geometry
    try:
        win = settings.get("window", {})
        w = int(win.get("width", 980))
        h = int(win.get("height", 560))
        x = win.get("x")
        y = win.get("y")
        if x is not None and y is not None:
            root.geometry(f"{w}x{h}+{int(x)}+{int(y)}")
        else:
            root.geometry(f"{w}x{h}")
    except Exception:
        pass

    root.mainloop()

if __name__ == "__main__":
    main()
