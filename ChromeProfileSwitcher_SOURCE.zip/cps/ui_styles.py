import tkinter as tk
from tkinter import ttk
from typing import Dict

_THEMES: Dict[str, Dict[str, str]] = {
    "Dark": {
        "root_bg": "#0b0b0b",
        "panel": "#121212",
        "panel2": "#161616",
        "fg": "#f2f2f2",
        "muted": "#b8b8b8",
        "entry_bg": "#0f0f0f",
        "entry_fg": "#ffffff",
        "border": "#2a2a2a",
        "sel_fg": "#000000",
    },
    "Midnight": {
        "root_bg": "#050914",
        "panel": "#0b1224",
        "panel2": "#0f1730",
        "fg": "#eaf0ff",
        "muted": "#aebad6",
        "entry_bg": "#070d1d",
        "entry_fg": "#ffffff",
        "border": "#203055",
        "sel_fg": "#000000",
    },
    "High Contrast": {
        "root_bg": "#000000",
        "panel": "#000000",
        "panel2": "#0a0a0a",
        "fg": "#ffffff",
        "muted": "#e0e0e0",
        "entry_bg": "#000000",
        "entry_fg": "#ffffff",
        "border": "#ffffff",
        "sel_fg": "#000000",
    },
    "Light": {
        "root_bg": "#f4f5f7",
        "panel": "#ffffff",
        "panel2": "#f0f2f5",
        "fg": "#101214",
        "muted": "#4b5563",
        "entry_bg": "#ffffff",
        "entry_fg": "#101214",
        "border": "#c9ced6",
        "sel_fg": "#ffffff",
    },
}

_ACCENTS: Dict[str, str] = {
    "Orange": "#ff9500",
    "Blue": "#4da3ff",
    "Green": "#34d399",
    "Purple": "#a78bfa",
    "Red": "#fb7185",
    "Yellow": "#fbbf24",
}

def theme_colors(theme: str = "Dark", accent: str = "Orange") -> Dict[str, str]:
    t = _THEMES.get(theme) or _THEMES["Dark"]
    a = _ACCENTS.get(accent) or _ACCENTS["Orange"]
    out = dict(t)
    out["accent"] = a
    out["sel_bg"] = a
    return out

def apply_theme(root: tk.Tk, theme: str = "Dark", accent: str = "Orange") -> None:
    c = theme_colors(theme, accent)

    style = ttk.Style(root)
    try:
        style.theme_use("clam")
    except Exception:
        pass

    root.configure(bg=c["root_bg"])

    # Global
    style.configure(".", background=c["panel"], foreground=c["fg"], bordercolor=c["border"],
                    lightcolor=c["border"], darkcolor=c["border"], focuscolor=c["accent"])
    style.configure("TFrame", background=c["panel"])
    style.configure("Card.TFrame", background=c["panel2"], relief="solid", borderwidth=1)
    style.configure("Title.TLabel", background=c["root_bg"], foreground=c["fg"], font=("Segoe UI", 20, "bold"))
    style.configure("Sub.TLabel", background=c["root_bg"], foreground=c["muted"], font=("Segoe UI", 9))
    style.configure("TLabel", background=c["panel"], foreground=c["fg"])
    style.configure("Muted.TLabel", background=c["panel"], foreground=c["muted"])

    style.configure("TCheckbutton", background=c["panel"], foreground=c["fg"])
    style.map("TCheckbutton", background=[("active", c["panel"])])

    style.configure("TEntry", fieldbackground=c["entry_bg"], foreground=c["entry_fg"],
                    insertcolor=c["entry_fg"], bordercolor=c["border"], lightcolor=c["border"], darkcolor=c["border"])

    style.configure("TButton", padding=(10, 6), relief="flat")
    style.map("TButton", relief=[("pressed", "sunken")])

    style.configure("Accent.TButton", background=c["accent"], foreground=c["sel_fg"])
    style.map("Accent.TButton",
              background=[("active", c["accent"]), ("pressed", c["accent"])],
              foreground=[("disabled", c["muted"])])

    style.configure("Ghost.TButton", background=c["panel"], foreground=c["fg"], borderwidth=1, relief="solid")
    style.map("Ghost.TButton", background=[("active", c["panel2"]), ("pressed", c["entry_bg"])])

    style.configure("Fav.TButton", background=c["panel2"], foreground=c["fg"], borderwidth=1, relief="solid")
    style.map("Fav.TButton", background=[("active", c["panel2"]), ("pressed", c["entry_bg"])])

    # Combobox styling (field)
    style.configure("TCombobox", fieldbackground=c["entry_bg"], background=c["panel"],
                    foreground=c["entry_fg"], arrowcolor=c["fg"], bordercolor=c["border"])
    style.map("TCombobox",
              fieldbackground=[("readonly", c["entry_bg"])],
              foreground=[("readonly", c["entry_fg"])],
              background=[("readonly", c["panel"])],
              selectbackground=[("readonly", c["entry_bg"])],
              selectforeground=[("readonly", c["entry_fg"])],
              )

    # Combobox popdown listbox (option database affects internal listbox)
    root.option_add("*TCombobox*Listbox.background", c["panel"])
    root.option_add("*TCombobox*Listbox.foreground", c["fg"])
    root.option_add("*TCombobox*Listbox.selectBackground", c["sel_bg"])
    root.option_add("*TCombobox*Listbox.selectForeground", c["sel_fg"])
    root.option_add("*TCombobox*Listbox.borderWidth", 0)

    # Notebook (tabs) - avoid unreadable default Windows greys
    style.configure("TNotebook", background=c["panel"], borderwidth=0)
    style.configure("TNotebook.Tab", background=c["panel2"], foreground=c["fg"], padding=(12, 7))
    style.map("TNotebook.Tab",
              background=[("selected", c["panel"]), ("active", c["panel2"])],
              foreground=[("selected", c["accent"]), ("active", c["fg"])])

def apply_dark_theme(root: tk.Tk) -> None:
    # Backwards-compatible alias
    apply_theme(root, "Dark", "Orange")
