import json
from typing import Any, Dict

def deep_merge(base: Dict[str, Any], incoming: Dict[str, Any]) -> Dict[str, Any]:
    """Return a new dict where incoming is merged onto base (recursive for dict values)."""
    out = dict(base)
    for k, v in (incoming or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)  # type: ignore[arg-type]
        else:
            out[k] = v
    return out

def mask_secrets(text: str) -> str:
    # Lightweight masking used for diagnostics / history.
    if not text:
        return text
    # mask common query params
    text = json.dumps(text)  # escape safely
    text = text.strip('"')
    # Replace query param values for likely secrets
    patterns = [
        r'(?i)(token|access_token|refresh_token|apikey|api_key|key|secret|password|pass|auth|bearer)=([^&\s]+)',
    ]
    for pat in patterns:
        text = __import__("re").sub(pat, r'\1=***', text)
    # mask long opaque strings (very conservative)
    text = __import__("re").sub(r'([A-Za-z0-9_\-]{24,})', lambda m: (m.group(0)[:6] + "***" + m.group(0)[-4:]), text)
    return text

def merge_into_settings(settings: Dict[str, Any], new_values: Dict[str, Any], defaults: Dict[str, Any]) -> None:
    """Merge imported settings into current settings dict in-place, preserving required defaults."""
    merged = deep_merge(defaults, settings)
    merged = deep_merge(merged, new_values)
    settings.clear()
    settings.update(merged)
