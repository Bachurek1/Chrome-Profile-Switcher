import ctypes
from ctypes import wintypes
from dataclasses import dataclass
from typing import Callable, Dict, Optional, Tuple

user32 = ctypes.WinDLL("user32", use_last_error=True)

WM_HOTKEY = 0x0312
PM_REMOVE = 0x0001

MOD_ALT = 0x0001
MOD_CONTROL = 0x0002
MOD_SHIFT = 0x0004
MOD_WIN = 0x0008

VK_CONTROL = 0x11
VK_SHIFT = 0x10
VK_MENU = 0x12  # ALT

# WinAPI bindings
RegisterHotKey = user32.RegisterHotKey
RegisterHotKey.argtypes = [wintypes.HWND, wintypes.INT, wintypes.UINT, wintypes.UINT]
RegisterHotKey.restype = wintypes.BOOL

UnregisterHotKey = user32.UnregisterHotKey
UnregisterHotKey.argtypes = [wintypes.HWND, wintypes.INT]
UnregisterHotKey.restype = wintypes.BOOL

PeekMessageW = user32.PeekMessageW
PeekMessageW.argtypes = [ctypes.POINTER(wintypes.MSG), wintypes.HWND, wintypes.UINT, wintypes.UINT, wintypes.UINT]
PeekMessageW.restype = wintypes.BOOL

GetAsyncKeyState = user32.GetAsyncKeyState
GetAsyncKeyState.argtypes = [wintypes.INT]
GetAsyncKeyState.restype = wintypes.SHORT


@dataclass
class HotkeyRegistration:
    hotkey: str
    modifiers: int
    vk: int
    callback: Callable[[], None]


def _vk_from_key_token(token: str) -> int:
    t = token.strip().upper()
    if not t:
        raise ValueError("Missing key")
    if len(t) == 1:
        ch = t
        # A-Z, 0-9
        code = ord(ch)
        if ord('A') <= code <= ord('Z') or ord('0') <= code <= ord('9'):
            return code
    if t.startswith("F") and t[1:].isdigit():
        n = int(t[1:])
        if 1 <= n <= 24:
            return 0x70 + (n - 1)  # VK_F1 = 0x70
    # Common alternatives
    aliases = {
        "SPACE": 0x20,
        "TAB": 0x09,
        "ESC": 0x1B,
        "ESCAPE": 0x1B,
        "ENTER": 0x0D,
        "RETURN": 0x0D,
    }
    if t in aliases:
        return aliases[t]
    raise ValueError(f"Unsupported key: {token}")


def parse_hotkey(hotkey: str) -> Tuple[int, int]:
    """
    Parse strings like: CTRL+SHIFT+ALT+S, CTRL+SHIFT+ALT+F12
    Returns (modifiers, vk)
    """
    if not hotkey:
        raise ValueError("Empty hotkey")
    parts = [p.strip() for p in hotkey.split("+") if p.strip()]
    if len(parts) < 2:
        raise ValueError("Hotkey must include modifiers + key (e.g. CTRL+SHIFT+ALT+S)")
    mods = 0
    key_token = parts[-1]
    for p in parts[:-1]:
        u = p.upper()
        if u in ("CTRL", "CONTROL"):
            mods |= MOD_CONTROL
        elif u == "SHIFT":
            mods |= MOD_SHIFT
        elif u in ("ALT", "MENU"):
            mods |= MOD_ALT
        elif u in ("WIN", "WINDOWS"):
            mods |= MOD_WIN
        else:
            raise ValueError(f"Unknown modifier: {p}")
    vk = _vk_from_key_token(key_token)
    return mods, vk


class WinGlobalHotkeyManager:
    """
    Windows global hotkeys via RegisterHotKey + polling WM_HOTKEY messages.

    Includes a fallback chord detector using GetAsyncKeyState edge detection, which
    helps in environments where WM_HOTKEY delivery is unreliable.
    """
    def __init__(self, hwnd_provider: Callable[[], int]):
        self._hwnd_provider = hwnd_provider
        self._next_id = 1
        self._regs: Dict[int, HotkeyRegistration] = {}
        self._last_async_down: Dict[int, bool] = {}

    def register(self, hotkey: str, callback: Callable[[], None]) -> int:
        mods, vk = parse_hotkey(hotkey)
        hwnd = wintypes.HWND(int(self._hwnd_provider() or 0))
        if not hwnd:
            raise RuntimeError("No valid HWND to register hotkey")
        hk_id = int(self._next_id)
        self._next_id += 1
        ok = bool(RegisterHotKey(hwnd, hk_id, mods, vk))
        if not ok:
            err = ctypes.get_last_error()
            raise OSError(err, "RegisterHotKey failed")
        self._regs[hk_id] = HotkeyRegistration(hotkey=hotkey, modifiers=mods, vk=vk, callback=callback)
        self._last_async_down[hk_id] = False
        return hk_id

    def unregister_all(self) -> None:
        hwnd = wintypes.HWND(int(self._hwnd_provider() or 0))
        for hk_id in list(self._regs.keys()):
            try:
                UnregisterHotKey(hwnd, int(hk_id))
            except Exception:
                pass
        self._regs.clear()
        self._last_async_down.clear()

    def poll(self) -> None:
        msg = wintypes.MSG()
        # Drain WM_HOTKEY messages
        try:
            while PeekMessageW(ctypes.byref(msg), wintypes.HWND(0), WM_HOTKEY, WM_HOTKEY, PM_REMOVE):
                hk_id = int(msg.wParam)
                reg = self._regs.get(hk_id)
                if reg:
                    try:
                        reg.callback()
                    except Exception:
                        pass
        except Exception:
            pass

        # Fallback chord detector
        try:
            for hk_id, reg in list(self._regs.items()):
                mods = int(reg.modifiers)
                vk = int(reg.vk)

                down = True
                if mods & MOD_CONTROL:
                    down = down and (GetAsyncKeyState(VK_CONTROL) & 0x8000 != 0)
                if mods & MOD_SHIFT:
                    down = down and (GetAsyncKeyState(VK_SHIFT) & 0x8000 != 0)
                if mods & MOD_ALT:
                    down = down and (GetAsyncKeyState(VK_MENU) & 0x8000 != 0)
                if mods & MOD_WIN:
                    # LWIN/RWIN
                    down = down and ((GetAsyncKeyState(0x5B) & 0x8000 != 0) or (GetAsyncKeyState(0x5C) & 0x8000 != 0))

                down = down and (GetAsyncKeyState(vk) & 0x8000 != 0)

                prev = self._last_async_down.get(hk_id, False)
                self._last_async_down[hk_id] = down
                if down and not prev:
                    try:
                        reg.callback()
                    except Exception:
                        pass
        except Exception:
            pass
