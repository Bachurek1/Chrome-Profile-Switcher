import platform

IS_WINDOWS = platform.system().lower() == "windows"
