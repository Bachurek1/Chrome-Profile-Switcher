import os
import time
import threading
import tkinter as tk
from tkinter import ttk, messagebox
from typing import Any, Dict, List, Optional, Tuple

from cps.chrome_profiles import ChromeProfile, list_profiles, get_profile_diagnostics
from cps.chrome_launcher import find_chrome_exe, open_profile
from cps.settings import save_settings
from cps.ui_styles import apply_theme, theme_colors
from cps.platform import IS_WINDOWS
from cps.tooltip import ToolTip

if IS_WINDOWS:
    from cps.hotkey_win import WinGlobalHotkeyManager
else:
    WinGlobalHotkeyManager = None  # type: ignore

from cps.overlay import QuickOverlay
from cps.personalise import PersonaliseDialog
from cps.diagnostics import DiagnosticsWindow

import traceback as _tray_tb
_TRAY_IMPORT_ERROR = None
try:
    from cps.tray import TrayManager
except Exception:
    TrayManager = None  # type: ignore
    _TRAY_IMPORT_ERROR = _tray_tb.format_exc()


def _write_tray_debug_log(message: str) -> str:
    """Write tray debug info to a log in the app data dir (best-effort)."""
    try:        base = os.path.dirname(get_settings_path())
    except Exception:
        base = os.path.join(os.path.expanduser("~"), "AppData", "Local", "ChromeProfileSwitcher")
    try:
        os.makedirs(base, exist_ok=True)
    except Exception:
        pass
    path = os.path.join(base, "tray_debug.log")
    try:
        with open(path, "a", encoding="utf-8") as f:
            f.write("\n" + ("="*60) + "\n")
            f.write(time.strftime("%Y-%m-%d %H:%M:%S") + "\n")
            f.write(message.strip() + "\n")
    except Exception:
        pass
    return path
class App:
    def __init__(self, root: tk.Tk, settings: Dict[str, Any]):
        self.root = root
        self.settings = settings

        self._hotkey_warned = False
        self._tray_mgr = None
        self._tray_available = False
        self._tray_error = None
        self._tray_import_error = _TRAY_IMPORT_ERROR
        self._tray_warned = False



        # Tray diagnostics (must exist even if tray never starts)
        self._tray_diag = {
            "attempted": False,
            "success": False,
            "hwnd": "",
            "last_error": "",
            "win32_failures": "",
            "start_thread": "",
            "tray_thread": "",
        }
        # Status strings must exist before any UI refresh calls
        self._hotkey_status = "Hotkey: (initialising)"
        self._tray_status = "Tray: N/A"
        self._overlay_status = "Overlay: Off"
        # Apply theme early (based on settings)
        self._apply_current_theme()

        self._chrome_exe = find_chrome_exe()
        self._profiles: List[ChromeProfile] = []
        self._filtered: List[ChromeProfile] = []
        self._selected: Optional[ChromeProfile] = None

        self._last_launch_ts = 0.0

        self._build_ui()
        self._load_profiles(force=False)
        self._refresh_results()

        # Ensure search box is focused by default on startup
        self.root.after(50, self._focus_search)

        self._overlay = None  # type: ignore
        try:
            self._overlay = QuickOverlay(
            root,
            on_query=self._overlay_query,
            on_open=self._overlay_open,
            width=int(self.settings.get("overlay", {}).get("width", 640)),
            max_results=int(self.settings.get("overlay", {}).get("max_results", 12))
        )
        except Exception:
            # Overlay must never break startup.
            self._overlay = None
            self._overlay_status = "Overlay: Unavailable"

        self._personalise_dlg = None  # Personalise window singleton

        self._hk_mgr = None
        self._hk_reg = None
        self._hotkey_status = "Hotkey: (not supported)"
        if IS_WINDOWS and WinGlobalHotkeyManager is not None:
            # Ensure a valid HWND exists before attempting RegisterHotKey
            try:
                self.root.update_idletasks()
                self.root.update()
            except Exception:
                pass
            self._hk_mgr = WinGlobalHotkeyManager(hwnd_provider=lambda: int(self.root.winfo_id()))
            # Defer registration slightly to ensure Tk has a valid HWND (avoids "initialising" / failed registers)
            self.root.after(250, self._install_hotkey)

        # Tray (optional) - must never break startup
        try:
            self._install_tray()
        except Exception:
            import traceback
            self._tray_mgr = None
            self._tray_available = False
            self._tray_error = traceback.format_exc()
            self._tray_status = "Tray: Unavailable"
            try:
                _write_tray_debug_log("Tray init crashed:\n" + self._tray_error)
            except Exception:
                pass

        self._update_status()

    # ---------------- Diagnostics / masking ----------------
    def _mask_url(self, url: str) -> str:
        # Remove obvious secrets in query strings
        try:
            if "?" in url:
                base, _q = url.split("?", 1)
                return base + "?***"
        except Exception:
            pass
        return url

    def _mask_command(self, cmd: str) -> str:
        s = cmd
        # Common patterns
        for key in ("token=", "access_token=", "apikey=", "api_key=", "password=", "passwd=", "secret="):
            if key in s.lower():
                # crude masking of key=value sequences
                parts = s.split()
                new_parts = []
                for p in parts:
                    pl = p.lower()
                    if key in pl and "=" in p:
                        k, _v = p.split("=", 1)
                        new_parts.append(k + "=***")
                    else:
                        new_parts.append(p)
                s = " ".join(new_parts)
                break
        # Mask any URL query strings
        out_parts = []
        for p in s.split():
            if p.startswith("http://") or p.startswith("https://"):
                out_parts.append(self._mask_url(p))
            else:
                out_parts.append(p)
        return " ".join(out_parts)

    def _record_last_launch(self, args: List[str]) -> None:
        cmd = " ".join(args)
        masked = self._mask_command(cmd)
        self.settings.setdefault("diagnostics", {})
        if not isinstance(self.settings["diagnostics"], dict):
            self.settings["diagnostics"] = {}
        self.settings["diagnostics"]["last_launch_command"] = cmd
        self.settings["diagnostics"]["last_launch_masked"] = masked
        self.settings["diagnostics"]["last_launch_time"] = int(time.time())

    def open_diagnostics(self) -> None:
        prof_diag = get_profile_diagnostics()
        last = self.settings.get("diagnostics", {}) if isinstance(self.settings.get("diagnostics"), dict) else {}
        def fmt_ts(ts: float) -> str:
            if not ts:
                return ""
            try:
                return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts))
            except Exception:
                return str(ts)

        info = {
            "chrome_path": self._chrome_exe or "",
            "user_data_path": prof_diag.get("user_data_dir") or "",
            "local_state_path": prof_diag.get("local_state_path") or "",
            "local_state_last_read": fmt_ts(float(prof_diag.get("local_state_last_read_ts") or 0)),
            "hotkey_status": self._hotkey_status,
            "last_launch": last.get("last_launch_command", ""),
            "last_launch_masked": last.get("last_launch_masked", ""),
            "tray_status": ("On" if self._tray_available else ("Off" if not self.settings.get("tray", {}).get("enabled", True) else "Unavailable")),
            "tray_import_error": (self._tray_import_error or ""),
            "tray_error": (self._tray_error or ""),
            "tray_init_attempted": self._tray_diag.get("attempted"),
            "tray_init_success": self._tray_diag.get("success"),
            "tray_hwnd": self._tray_diag.get("hwnd"),
            "tray_last_error": self._tray_diag.get("last_error"),
            "tray_win32_failures": self._tray_diag.get("win32_failures"),
            "tray_start_thread": self._tray_diag.get("start_thread"),
            "tray_thread": self._tray_diag.get("tray_thread"),
        }
        # Refresh diagnostics from tray manager (non-fatal)
        try:
            if self._tray_mgr is not None and hasattr(self._tray_mgr, "get_diagnostics"):
                info.update(self._tray_mgr.get_diagnostics())
        except Exception:
            pass
        DiagnosticsWindow(self.root, info)

    # ---------------- Theme ----------------
    def _apply_current_theme(self) -> None:
        ui = self.settings.get("ui", {}) if isinstance(self.settings.get("ui"), dict) else {}
        theme = str(ui.get("theme", "Dark"))
        accent = str(ui.get("accent", "Orange"))
        apply_theme(self.root, theme, accent)
        self.colors = theme_colors(theme, accent)

    def _apply_listbox_theme(self) -> None:
        c = self.colors
        try:
            self.listbox.configure(
                bg=c["panel"],
                fg=c["fg"],
                selectbackground=c["sel_bg"],
                selectforeground=c["sel_fg"],
                highlightbackground=c["border"],
                highlightcolor=c["border"]
            )
        except Exception:
            pass

    # ---------------- UI ----------------
    def _build_ui(self) -> None:
        c = self.colors

        self._build_menu()

        # Header
        header = ttk.Frame(self.root)
        header.pack(fill="x", padx=16, pady=(14, 8))

        title = ttk.Label(header, text="Chrome Profile Switcher", style="Title.TLabel")
        title.pack(anchor="w")

        sub = ttk.Label(
            header,
            text="Enter opens profile. Ctrl+Enter opens portal. Esc clears search.",
            style="Sub.TLabel"
        )
        sub.pack(anchor="w", pady=(4, 0))

        # Search row
        search_row = ttk.Frame(self.root)
        search_row.pack(fill="x", padx=16, pady=(6, 8))

        ttk.Label(search_row, text="Search:", style="Muted.TLabel").pack(side="left", padx=(0, 8))

        self.search_var = tk.StringVar()
        self.search_entry = ttk.Entry(search_row, textvariable=self.search_var)
        self.search_entry.pack(side="left", fill="x", expand=True)
        self.search_entry.bind("<KeyRelease>", self._on_search_change)
        self.search_entry.bind("<Escape>", self._on_escape_clear)
        self.search_entry.bind("<Return>", self._on_enter_open_profile)
        self.search_entry.bind("<Control-Return>", self._on_ctrl_enter_open_portal)
        self.search_entry.bind("<Up>", self._on_search_up)
        self.search_entry.bind("<Down>", self._on_search_down)

        self.clear_btn = ttk.Button(search_row, text="Clear", style="Ghost.TButton", command=self._clear_search, width=8)
        self.clear_btn.pack(side="left", padx=(10, 0))

        self.fav_only_var = tk.BooleanVar(value=bool(self.settings.get("filters", {}).get("favourites_only", False)))
        self.recent_only_var = tk.BooleanVar(value=bool(self.settings.get("filters", {}).get("recent_only", False)))

        fav_cb = ttk.Checkbutton(search_row, text="★ Favourites only", variable=self.fav_only_var, command=self._on_filter_change)
        fav_cb.pack(side="left", padx=(18, 0))
        ToolTip(fav_cb, "Show only profiles you have starred as favourites.")

        rec_cb = ttk.Checkbutton(search_row, text="🕘 Recent only", variable=self.recent_only_var, command=self._on_filter_change)
        rec_cb.pack(side="left", padx=(12, 0))
        ToolTip(rec_cb, "Show only profiles you have opened recently.")

        # Main content
        main = ttk.Frame(self.root)
        main.pack(fill="both", expand=True, padx=16, pady=(0, 10))

        main.columnconfigure(0, weight=1, uniform="col")
        main.columnconfigure(1, weight=2, uniform="col")
        main.rowconfigure(0, weight=1)

        left_card = ttk.Frame(main, style="Card.TFrame", padding=12)
        left_card.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        right_card = ttk.Frame(main, style="Card.TFrame", padding=12)
        right_card.grid(row=0, column=1, sticky="nsew")

        ttk.Label(left_card, text="Profiles").pack(anchor="w")

        list_frame = ttk.Frame(left_card)
        list_frame.pack(fill="both", expand=True, pady=(8, 0))

        self.listbox = tk.Listbox(
            list_frame,
            activestyle="none",
            highlightthickness=1,
            relief="flat",
            bd=0,
            exportselection=False
        )
        self.listbox.pack(side="left", fill="both", expand=True)

        sb = ttk.Scrollbar(list_frame, orient="vertical", command=self.listbox.yview)
        sb.pack(side="right", fill="y")
        self.listbox.configure(yscrollcommand=sb.set)

        self._apply_listbox_theme()

        self.listbox.bind("<<ListboxSelect>>", self._on_select)
        self.listbox.bind("<Return>", self._on_enter_open_profile)
        self.listbox.bind("<Control-Return>", self._on_ctrl_enter_open_portal)
        self.listbox.bind("<Double-Button-1>", self._on_enter_open_profile)

        # Right details
        ttk.Label(right_card, text="Selection").pack(anchor="w")

        self.sel_title = ttk.Label(right_card, text="(none)", style="Muted.TLabel")
        self.sel_title.pack(anchor="w", pady=(8, 10))

        # Favourite button
        self.fav_btn = ttk.Button(right_card, text="★ Favourite", style="Fav.TButton", command=self._toggle_favourite)
        self.fav_btn.pack(fill="x")

        self.open_only_var = tk.BooleanVar(value=False)
        open_only_cb = ttk.Checkbutton(
            right_card,
            text="Open profile only (no portal)",
            variable=self.open_only_var,
            command=self._sync_portal_state
        )
        open_only_cb.pack(anchor="w", pady=(10, 0))
        ToolTip(open_only_cb, "If enabled, only opens the Chrome profile (no portal URL).")

        # Portal row: entry + dropdown
        ttk.Label(right_card, text="Open portal:", style="Muted.TLabel").pack(anchor="w", pady=(12, 4))

        portal_row = ttk.Frame(right_card)
        portal_row.pack(fill="x")

        self.portal_var = tk.StringVar(value=str(self.settings.get("default_portal", "")))
        self.portal_entry = ttk.Entry(portal_row, textvariable=self.portal_var)
        self.portal_entry.pack(side="left", fill="x", expand=True)
        self.portal_entry.bind("<Return>", self._on_enter_open_profile)
        self.portal_entry.bind("<Control-Return>", self._on_ctrl_enter_open_portal)
        ToolTip(self.portal_entry, "Portal URL to open (Ctrl+Enter).")

        self.portal_pick_var = tk.StringVar(value="")
        self.portal_combo = ttk.Combobox(portal_row, state="readonly", textvariable=self.portal_pick_var, width=18)
        self.portal_combo.pack(side="left", padx=(10, 0))
        ToolTip(self.portal_combo, "Quick-pick a named portal.")
        self.portal_combo.bind("<<ComboboxSelected>>", self._on_portal_pick)

        self.save_profile_portal_btn = ttk.Button(right_card, text="Save as profile default", style="Ghost.TButton", command=self._save_portal_as_profile_default)
        self.save_profile_portal_btn.pack(fill="x", pady=(10, 0))
        ToolTip(self.save_profile_portal_btn, "Save the current portal choice as the default for this profile.")

        self.default_label = ttk.Label(right_card, text=f"Global default portal: {self.settings.get('default_portal','')}", style="Muted.TLabel")
        self.default_label.pack(anchor="w", pady=(8, 0))

        # Actions
        actions = ttk.Frame(right_card)
        actions.pack(fill="x", pady=(14, 0))

        self.open_btn = ttk.Button(actions, text="Open Profile", style="Accent.TButton", command=self._launch)
        self.open_btn.pack(side="left")

        self.open_portal_btn = ttk.Button(actions, text="Open Portal", style="Ghost.TButton", command=self._launch_with_portal)
        self.open_portal_btn.pack(side="left", padx=(10, 0))

        # Status bar
        self.status = ttk.Label(self.root, text="", style="Muted.TLabel")
        self.status.pack(fill="x", padx=16, pady=(0, 12))

        # Global keybinds (non-invasive)
        self.root.bind("<Escape>", self._on_escape_clear)
        self.root.bind("<Control-Return>", self._on_ctrl_enter_open_portal)
        self.root.bind("<Return>", self._on_enter_open_profile)

        self._refresh_portal_dropdown()

    def _build_menu(self) -> None:
        menubar = tk.Menu(self.root)

        m_profiles = tk.Menu(menubar, tearoff=0)
        m_profiles.add_command(label="Refresh Profiles", command=self.refresh_profiles)
        m_profiles.add_separator()
        m_profiles.add_command(label="Exit", command=self.root.quit)
        menubar.add_cascade(label="Profiles", menu=m_profiles)

        m_settings = tk.Menu(menubar, tearoff=0)
        m_settings.add_command(label="Personalise…", command=self.open_personalise_dialog)
        menubar.add_cascade(label="Settings", menu=m_settings)

        m_help = tk.Menu(menubar, tearoff=0)
        m_help.add_command(label="Diagnostics…", command=self.open_diagnostics)
        menubar.add_cascade(label="Help", menu=m_help)

        self.root.config(menu=menubar)

    # ---------------- Portals helpers ----------------
    def _portal_list(self) -> List[Dict[str, str]]:
        portals = self.settings.get("portal_urls")
        out: List[Dict[str, str]] = []
        if isinstance(portals, list):
            for p in portals:
                if isinstance(p, dict):
                    name = str(p.get("name", "")).strip()
                    url = str(p.get("url", "")).strip()
                    if name and url:
                        out.append({"name": name, "url": url})
        return out

    def _portal_map(self) -> Dict[str, str]:
        return {p["name"]: p["url"] for p in self._portal_list()}

    def _refresh_portal_dropdown(self) -> None:
        names = sorted([p["name"] for p in self._portal_list()], key=lambda s: s.casefold())
        self.portal_combo.configure(values=[""] + names)
        # do not force-select anything

    def _resolve_portal_for_profile(self, profile_dir: str) -> str:
        # 1) per-profile override URL
        overrides = self.settings.get("per_profile_portal_override", {}) or {}
        if isinstance(overrides, dict):
            o = str(overrides.get(profile_dir, "")).strip()
            if o:
                return o
        # 2) per-profile named portal assignment
        names = self.settings.get("per_profile_portal_name", {}) or {}
        if isinstance(names, dict):
            pname = str(names.get(profile_dir, "")).strip()
            if pname:
                url = self._portal_map().get(pname)
                if url:
                    return url
        # 3) global default (named portal if set, otherwise URL)
        gname = str(self.settings.get("global_default_portal_name", "")).strip()
        if gname:
            url = self._portal_map().get(gname)
            if url:
                return url
        return str(self.settings.get("default_portal", "")).strip()

    # ---------------- Data ----------------
    def _load_profiles(self, force: bool = False) -> None:
        self._profiles = list_profiles(force_refresh=force)

    def refresh_profiles(self) -> None:
        # preserve current selection dir_name if possible
        current = self._selected.dir_name if self._selected else None
        self._load_profiles(force=True)
        self._refresh_results(preserve_dir=current)

    def _format_profile_display(self, p: ChromeProfile) -> str:
        favs = set(self.settings.get("favourites", []))
        star = "★ " if p.dir_name in favs else "  "
        return f"{star}{p.display_name} ({p.dir_name})"

    def _refresh_results(self, preserve_dir: Optional[str] = None) -> None:
        q = (self.search_var.get() or "").strip().lower()
        fav_only = bool(self.fav_only_var.get())
        recent_only = bool(self.recent_only_var.get())

        favs = set(self.settings.get("favourites", []))
        recents = [r.get("profile") for r in self.settings.get("recents", []) if isinstance(r, dict)]

        results: List[ChromeProfile] = []
        for p in self._profiles:
            if fav_only and p.dir_name not in favs:
                continue
            if recent_only and p.dir_name not in recents:
                continue
            text = f"{p.display_name} {p.dir_name}".lower()
            if q and q not in text:
                continue
            results.append(p)

        if recent_only:
            order = {name: i for i, name in enumerate(recents)}
            results.sort(key=lambda p: order.get(p.dir_name, 999999))
        else:
            results.sort(key=lambda p: (p.display_name.lower(), p.dir_name.lower()))

        self._filtered = results
        self.listbox.delete(0, tk.END)
        for p in results:
            self.listbox.insert(tk.END, self._format_profile_display(p))

        # Select preserved if possible
        sel_idx = 0
        if preserve_dir:
            for i, p in enumerate(results):
                if p.dir_name == preserve_dir:
                    sel_idx = i
                    break

        if results:
            self.listbox.selection_set(sel_idx)
            self.listbox.activate(sel_idx)
            self._set_selected(results[sel_idx])
            try:
                self.listbox.see(sel_idx)
            except Exception:
                pass
        else:
            self._set_selected(None)

        self._update_status()

    def _set_selected(self, p: Optional[ChromeProfile]) -> None:
        self._selected = p
        if not p:
            self.sel_title.config(text="(none)")
            self.fav_btn.state(["disabled"])
            self.open_btn.state(["disabled"])
            self.open_portal_btn.state(["disabled"])
            self.save_profile_portal_btn.state(["disabled"])
            return

        self.sel_title.config(text=f"{p.display_name} ({p.dir_name})")
        self.fav_btn.state(["!disabled"])
        self.open_btn.state(["!disabled"])
        self.open_portal_btn.state(["!disabled"])
        self.save_profile_portal_btn.state(["!disabled"])

        self._sync_fav_button()
        self._apply_profile_portal_default()
        self._sync_portal_state()

    def _sync_fav_button(self) -> None:
        if not self._selected:
            return
        favs = set(self.settings.get("favourites", []))
        self.fav_btn.config(text="★ Favourited" if self._selected.dir_name in favs else "☆ Favourite")

    def _apply_profile_portal_default(self) -> None:
        if not self._selected:
            return
        url = self._resolve_portal_for_profile(self._selected.dir_name)
        self.portal_var.set(str(url))
        self.default_label.config(text=f"Global default portal: {self.settings.get('default_portal','')}")
        self.portal_pick_var.set("")  # don't force any selection

    # ---------------- Events ----------------
    def _on_search_change(self, event=None) -> None:
        self._refresh_results(preserve_dir=self._selected.dir_name if self._selected else None)

    def _on_escape_clear(self, event=None) -> None:
        self._clear_search()

    def _focus_search(self, *_args) -> None:
        """Focus the search entry so typing immediately filters profiles."""
        try:
            self.search_entry.focus_set()
            # Put caret at end; don't forcibly select all (less annoying)
            try:
                self.search_entry.icursor("end")
            except Exception:
                pass
        except Exception:
            pass

    def _clear_search(self) -> None:
        self.search_var.set("")
        self.search_entry.focus_set()
        self._refresh_results(preserve_dir=self._selected.dir_name if self._selected else None)

    def _on_enter_open_profile(self, event=None) -> None:
        self._ensure_first_selection()
        self._launch()

    def _on_ctrl_enter_open_portal(self, event=None) -> None:
        self._ensure_first_selection()
        self._launch_with_portal()


    def _ensure_first_selection(self) -> None:
        try:
            if self.listbox.size() <= 0:
                return
            sel = self.listbox.curselection()
            if sel:
                return
            # select first visible item
            self.listbox.selection_clear(0, tk.END)
            self.listbox.selection_set(0)
            self.listbox.activate(0)
            self.listbox.see(0)
            self._on_select()
        except Exception:
            pass

    def _on_search_up(self, event=None):
        try:
            n = self.listbox.size()
            if n <= 0:
                return "break"
            sel = self.listbox.curselection()
            idx = int(sel[0]) if sel else 0
            idx = max(0, idx - 1)
            self.listbox.selection_clear(0, tk.END)
            self.listbox.selection_set(idx)
            self.listbox.activate(idx)
            self.listbox.see(idx)
            self._on_select()
        except Exception:
            pass
        return "break"

    def _on_search_down(self, event=None):
        try:
            n = self.listbox.size()
            if n <= 0:
                return "break"
            sel = self.listbox.curselection()
            idx = int(sel[0]) if sel else -1
            idx = min(n - 1, idx + 1)
            self.listbox.selection_clear(0, tk.END)
            self.listbox.selection_set(idx)
            self.listbox.activate(idx)
            self.listbox.see(idx)
            self._on_select()
        except Exception:
            pass
        return "break"
    def _on_select(self, event=None) -> None:
        sel = self.listbox.curselection()
        if not sel:
            return
        idx = int(sel[0])
        if 0 <= idx < len(self._filtered):
            self._set_selected(self._filtered[idx])

    def _on_filter_change(self) -> None:
        self.settings.setdefault("filters", {})
        self.settings["filters"]["favourites_only"] = bool(self.fav_only_var.get())
        self.settings["filters"]["recent_only"] = bool(self.recent_only_var.get())
        save_settings(self.settings)
        self._refresh_results(preserve_dir=self._selected.dir_name if self._selected else None)

    def _sync_portal_state(self) -> None:
        if self.open_only_var.get():
            self.portal_entry.state(["disabled"])
            self.portal_combo.state(["disabled"])
            self.open_portal_btn.state(["disabled"])
            self.save_profile_portal_btn.state(["disabled"])
        else:
            self.portal_entry.state(["!disabled"])
            self.portal_combo.state(["!disabled"])
            self.save_profile_portal_btn.state(["!disabled"])
            if self._selected:
                self.open_portal_btn.state(["!disabled"])

    def _on_portal_pick(self, _event=None) -> None:
        name = (self.portal_pick_var.get() or "").strip()
        if not name:
            return
        url = self._portal_map().get(name)
        if url:
            self.portal_var.set(url)

    # ---------------- Actions ----------------
    def _toggle_favourite(self) -> None:
        if not self._selected:
            return
        favs = list(self.settings.get("favourites", []))
        if self._selected.dir_name in favs:
            favs = [x for x in favs if x != self._selected.dir_name]
        else:
            favs.append(self._selected.dir_name)
        self.settings["favourites"] = favs
        save_settings(self.settings)
        self._refresh_results(preserve_dir=self._selected.dir_name)
        self._sync_fav_button()

    def _save_portal_as_profile_default(self) -> None:
        if not self._selected:
            return
        profile_dir = self._selected.dir_name
        current_url = (self.portal_var.get() or "").strip()

        # Decide whether to save by named portal or by override:
        name_map = self._portal_map()
        chosen_name = (self.portal_pick_var.get() or "").strip()

        self.settings.setdefault("per_profile_portal_name", {})
        self.settings.setdefault("per_profile_portal_override", {})
        if not isinstance(self.settings["per_profile_portal_name"], dict):
            self.settings["per_profile_portal_name"] = {}
        if not isinstance(self.settings["per_profile_portal_override"], dict):
            self.settings["per_profile_portal_override"] = {}

        saved_as = None

        if chosen_name and name_map.get(chosen_name) == current_url:
            # Save as named portal assignment
            self.settings["per_profile_portal_name"][profile_dir] = chosen_name
            self.settings["per_profile_portal_override"].pop(profile_dir, None)
            # keep legacy per_profile_portal cleared for this profile
            if isinstance(self.settings.get("per_profile_portal"), dict):
                self.settings["per_profile_portal"].pop(profile_dir, None)
            saved_as = f"named portal: {chosen_name}"
        else:
            # Save as override URL
            if current_url:
                self.settings["per_profile_portal_override"][profile_dir] = current_url
                self.settings.setdefault("per_profile_portal", {})
                if isinstance(self.settings["per_profile_portal"], dict):
                    self.settings["per_profile_portal"][profile_dir] = current_url
                # if we store override, clear named portal assignment to avoid confusion
                if isinstance(self.settings["per_profile_portal_name"], dict):
                    self.settings["per_profile_portal_name"].pop(profile_dir, None)
                saved_as = "override URL"
            else:
                # Clear any mapping
                self.settings["per_profile_portal_override"].pop(profile_dir, None)
                self.settings["per_profile_portal_name"].pop(profile_dir, None)
                if isinstance(self.settings.get("per_profile_portal"), dict):
                    self.settings["per_profile_portal"].pop(profile_dir, None)
                saved_as = "cleared (fall back to global)"

        save_settings(self.settings)
        messagebox.showinfo("Saved", f"Saved portal default for {self._selected.display_name} as {saved_as}.")

    def _launch(self) -> None:
        self._launch_impl(open_portal=False)

    def _launch_with_portal(self) -> None:
        self._launch_impl(open_portal=True)

    def _launch_impl(self, open_portal: bool) -> None:
        if not self._selected:
            return
        now = time.time()
        if now - self._last_launch_ts < 0.25:
            return
        self._last_launch_ts = now

        if not self._chrome_exe:
            messagebox.showerror("Chrome not found", "Could not find chrome.exe on this machine.")
            return

        url = None
        if open_portal and not self.open_only_var.get():
            url = (self.portal_var.get() or "").strip() or None

        # Record last launch (for Diagnostics) before launching
        args = [self._chrome_exe, f"--profile-directory={self._selected.dir_name}"]
        if url:
            args.append(url)
        self._record_last_launch(args)

        open_profile(self._chrome_exe, self._selected.dir_name, url=url)
        self._add_recent(self._selected.dir_name)
        save_settings(self.settings)
        self._update_status()

    def _add_recent(self, profile_dir_name: str) -> None:
        recents = [r for r in self.settings.get("recents", []) if isinstance(r, dict)]
        recents = [r for r in recents if r.get("profile") != profile_dir_name]
        recents.insert(0, {"profile": profile_dir_name, "ts": int(time.time())})
        self.settings["recents"] = recents[:50]

    # ---------------- Overlay ----------------
    def _overlay_query(self, q: str) -> List[Tuple[str, str]]:
        ql = (q or "").strip().lower()
        favs = set(self.settings.get("favourites", []))

        # If no query, prefer "recents from this app" (most recent first).
        # Falls back to A–Z list if no recents exist.
        if not ql:
            recent_dirs: List[str] = []
            for r in self.settings.get("recents", []):
                if isinstance(r, dict):
                    d = r.get("profile") or r.get("dir_name") or r.get("profile_dir")
                    if isinstance(d, str) and d and d not in recent_dirs:
                        recent_dirs.append(d)

            by_dir = {p.dir_name: p for p in self._profiles}
            items: List[Tuple[str, str]] = []
            for d in recent_dirs:
                p = by_dir.get(d)
                if not p:
                    continue
                star = "★" if p.dir_name in favs else " "
                label = f"{star}  {p.display_name}  —  {p.dir_name}"
                items.append((p.dir_name, label))

            if items:
                return items

        # Otherwise show filtered A–Z results
        items2: List[Tuple[str, str]] = []
        for p in self._profiles:
            text = f"{p.display_name} {p.dir_name}".lower()
            if ql and ql not in text:
                continue
            star = "★" if p.dir_name in favs else " "
            label = f"{star}  {p.display_name}  —  {p.dir_name}"
            items2.append((p.dir_name, label))
        items2.sort(key=lambda t: t[1].lower())
        return items2

    def _overlay_open(self, profile_dir_name: str) -> None:
        match = next((p for p in self._profiles if p.dir_name == profile_dir_name), None)
        if match:
            self._set_selected(match)
            try:
                idx = next(i for i, p in enumerate(self._filtered) if p.dir_name == profile_dir_name)
                self.listbox.selection_clear(0, tk.END)
                self.listbox.selection_set(idx)
                self.listbox.activate(idx)
                self.listbox.see(idx)
            except Exception:
                pass
            self._launch_with_portal()

    def _ensure_overlay(self) -> Optional[QuickOverlay]:
        """Ensure overlay object exists. Overlay must never break app."""
        if getattr(self, "_overlay", None) is not None:
            return self._overlay  # type: ignore
        try:
            self._overlay = QuickOverlay(
                self.root,
                on_query=self._overlay_query,
                on_open=self._overlay_open,
                width=int(self.settings.get("overlay", {}).get("width", 640)),
                max_results=int(self.settings.get("overlay", {}).get("max_results", 12))
            )
            return self._overlay  # type: ignore
        except Exception:
            self._overlay = None
            self._overlay_status = "Overlay: Unavailable"
            return None

    def _toggle_overlay(self) -> None:
        if not bool(self.settings.get("overlay_enabled", True)):
            return
        ov = self._ensure_overlay()
        if not ov:
            return
        if str(ov.state()) == "withdrawn":
            ov.show()
        else:
            ov.hide()
        self._update_status()

    # ---------------- Settings dialog ----------------
    def open_personalise_dialog(self) -> None:
        # Singleton: if already open, bring to front instead of creating a new one
        try:
            if self._personalise_dlg is not None and getattr(self._personalise_dlg, "winfo_exists", lambda: 0)():
                try:
                    self._personalise_dlg.deiconify()
                except Exception:
                    pass
                try:
                    self._personalise_dlg.lift()
                    self._personalise_dlg.focus_force()
                except Exception:
                    pass
                return
        except Exception:
            pass

        dlg = PersonaliseDialog(
            self.root,
            self.settings,
            self._profiles,
            hotkey_status_text=self._hotkey_status,
            test_hotkey_callback=self._toggle_overlay,
            validate_hotkey_callback=self.validate_hotkey,
            set_hotkey_callback=self.set_hotkey,
            on_applied=self._on_settings_applied
        )

        self._personalise_dlg = dlg
        try:
            dlg.protocol("WM_DELETE_WINDOW", dlg.destroy)
            dlg.bind("<Destroy>", lambda e: setattr(self, "_personalise_dlg", None))
        except Exception:
            pass

    def _on_settings_applied(self) -> None:
        # Re-theme whole app & refresh portal dropdown + default label + portal for selected
        self._apply_current_theme()
        self._apply_listbox_theme()
        self._refresh_portal_dropdown()
        if self._selected:
            self._apply_profile_portal_default()
        # Apply tray enable/disable changes
        self._sync_tray_state()
        save_settings(self.settings)
        self._update_status()

    def _sync_tray_state(self) -> None:
        """Start/stop tray based on current settings."""
        tray_cfg = self.settings.get("tray") if isinstance(self.settings.get("tray"), dict) else {}
        enabled = bool(tray_cfg.get("enabled", True)) if isinstance(tray_cfg, dict) else True

        if not enabled:
            if self._tray_mgr is not None:
                try:
                    self._tray_mgr.stop()
                except Exception:
                    pass
                self._tray_mgr = None
            self._tray_status = "Tray: Off"
            return

        # If enabled and not currently running, try to start
        if self._tray_mgr is None:
            self._install_tray()

    # ---------------- Hotkey ----------------
    def _apply_hotkey_string(self, hotkey: str, warn: bool = True) -> bool:
        """Attempt to (re)register the global hotkey. Returns True if registered."""
        if not self._hk_mgr:
            self._hotkey_status = "Hotkey: (not supported)"
            return False

        hotkey = (hotkey or "").strip()
        if not hotkey:
            self._hotkey_status = "Hotkey: (disabled)"
            try:
                self._hk_mgr.unregister_all()
            except Exception:
                pass
            return False

        try:
            self._hk_mgr.unregister_all()
        except Exception:
            pass

        try:
            self._hk_mgr.register(hotkey, self._toggle_overlay)
            self._hotkey_status = f"Hotkey: {hotkey}"
            return True
        except Exception as e:
            self._hotkey_status = f"Hotkey: {hotkey} (FAILED)"
            if warn and (not self._hotkey_warned):
                self._hotkey_warned = True
                messagebox.showwarning(
                    "Hotkey not available",
                    "Global hotkey failed to register.\n"
                    "It may be in use by another app.\n\n"
                    f"{e}"
                )
            return False

    def set_hotkey(self, hotkey: str) -> bool:
        """Update settings + re-register hotkey."""
        ok = self._apply_hotkey_string(hotkey, warn=True)
        if ok:
            self.settings["hotkey"] = hotkey
            save_settings(self.settings)
        return ok

    def validate_hotkey(self, hotkey: str) -> bool:
        """Try registering the hotkey (no save). Restores current if it fails."""
        current = str(self.settings.get("hotkey", "")).strip()
        ok = self._apply_hotkey_string(hotkey, warn=False)
        if not ok:
            if current:
                self._apply_hotkey_string(current, warn=False)
        return ok

    def _install_hotkey(self) -> None:
        hotkey = str(self.settings.get("hotkey", "CTRL+SHIFT+ALT+S"))
        self._apply_hotkey_string(hotkey, warn=True)
        self._schedule_hotkey_poll()
    def _schedule_hotkey_poll(self) -> None:
        if not self._hk_mgr:
            return
        try:
            self._hk_mgr.poll()
        except Exception:
            pass
        self.root.after(30, self._schedule_hotkey_poll)

    # ---------------- Tray (optional) ----------------
    def _install_tray(self) -> None:
        self._tray_diag["attempted"] = True
        self._tray_diag["start_thread"] = threading.current_thread().name
        tray_cfg = self.settings.get("tray") if isinstance(self.settings.get("tray"), dict) else {}
        enabled = True
        if isinstance(tray_cfg, dict):
            enabled = bool(tray_cfg.get("enabled", True))

        if not enabled:
            self._tray_status = "Tray: Off"
            return

        if TrayManager is None:
            self._tray_status = "Tray: Unavailable"
            self._tray_available = False
            reason = (self._tray_import_error or "").strip()
            self._tray_diag["attempted"] = True
            self._tray_diag["success"] = False
            self._tray_diag["start_thread"] = threading.current_thread().name
            try:
                log_path = _write_tray_debug_log("Tray import failed:\n" + (reason or "(no traceback captured)"))
            except Exception:
                log_path = ""
            if not self._tray_warned:
                self._tray_warned = True
                try:
                    import tkinter.messagebox as mb
                    first = reason.splitlines()[0] if reason else "(no details)"
                    mb.showwarning(
                        "Tray unavailable",
                        "System tray could not be initialised.\n\n"
                        "Reason (first line):\n"
                        f"{first}\n\n"
                        f"Full log: {log_path}",
                    )
                except Exception:
                    pass
            return

        try:
            self._tray_error = None
            self._tray_mgr = TrayManager(
                title="Chrome Profile Switcher",
                on_show=lambda: self.root.after(0, self._tray_show),
                on_search=lambda: self.root.after(0, self._tray_search),
                on_settings=lambda: self.root.after(0, self.open_personalise_dialog),
                on_open=lambda: self.root.after(0, self._tray_open),
                on_diagnostics=lambda: self.root.after(0, self.open_diagnostics),
                on_quit=lambda: self.root.after(0, self._tray_quit),
            )
            self._tray_available = True
            self._tray_status = "Tray: Starting"
            try:
                self._tray_mgr.start()
            except Exception as _e:
                self._tray_error = str(_e)
                self._tray_status = "Tray: Failed"
                # Retry once shortly after startup (Explorer/tray can be late during logon)
                if not getattr(self, "_tray_retry_scheduled", False):
                    self._tray_retry_scheduled = True
                    self.root.after(2000, self._retry_tray_start)
                try:
                    _write_tray_debug_log("Tray start failed: " + self._tray_error)
                except Exception:
                    pass
            _write_tray_debug_log("Tray init attempted")
            try:
                self.root.after(250, lambda: self._tray_poll_status(5000))
            except Exception:
                pass
            try:
                if hasattr(self._tray_mgr, "get_diagnostics"):
                    self._tray_diag.update(self._tray_mgr.get_diagnostics())
            except Exception:
                pass
        except Exception:
            import traceback
            self._tray_mgr = None
            self._tray_available = False
            self._tray_error = traceback.format_exc()
            self._tray_status = "Tray: Unavailable"

        if not getattr(self._tray_mgr, "available", False):
            reason = getattr(self._tray_mgr, "unavailable_reason", None) or ""
            self._tray_status = "Tray: Unavailable"
            if reason:
                # Keep in status but don't spam popups
                self._tray_status = "Tray: Unavailable"
            return

        # Start is async (Win32 window/icon is created on a worker thread).
        # Don't mark the tray as "Failed" just because success isn't set yet.
        started = False
        try:
            started = bool(self._tray_mgr.start())
        except Exception:
            started = False

        try:
            if self._tray_mgr is not None and hasattr(self._tray_mgr, "get_diagnostics"):
                self._tray_diag.update(self._tray_mgr.get_diagnostics())
        except Exception:
            pass

        if started:
            self._tray_status = "Tray: Starting"
        else:
            self._tray_status = "Tray: Failed"

        # Post-check / polling to reflect async tray init outcome (non-fatal)
        # Poll a few times to avoid false "Failed" before the worker thread
        # has created the hidden HWND / added the notify icon.
        try:
            def _tray_postcheck(remaining: int = 10) -> None:
                try:
                    if self._tray_mgr is None or not hasattr(self._tray_mgr, "get_diagnostics"):
                        return
                    d = self._tray_mgr.get_diagnostics()
                    if d:
                        self._tray_diag.update(d)
                        success = bool(d.get("success"))
                        attempted = bool(d.get("attempted"))
                        failures = str(d.get("win32_failures") or "").strip()

                        if success:
                            self._tray_available = True
                            self._tray_status = "Tray: On"
                            self._update_status()
                            return

                        # If we have concrete Win32 failures recorded, treat as failed.
                        if attempted and failures:
                            self._tray_available = False
                            self._tray_status = "Tray: Failed"
                            self._update_status()
                            return

                        # Otherwise it's still starting. Keep polling a bit.
                        self._tray_available = False
                        self._tray_status = "Tray: Starting"
                        self._update_status()

                    if remaining > 0:
                        self.root.after(500, lambda: _tray_postcheck(remaining - 1))
                    else:
                        # Timed out waiting for success; mark failed only if we never succeeded.
                        if not bool(self._tray_diag.get("success")):
                            self._tray_available = False
                            self._tray_status = "Tray: Failed"
                            self._update_status()
                except Exception:
                    pass

            self.root.after(500, _tray_postcheck)
        except Exception:
            pass

    def _retry_tray_start(self) -> None:
        try:
            if self._tray_mgr:
                self._tray_status = "Tray: Starting"
                self._tray_mgr.start()
        except Exception as e:
            self._tray_error = str(e)
            self._tray_status = "Tray: Failed"

    def _tray_show(self) -> None:
        try:
            self.root.deiconify()
            self.root.lift()
            self.root.focus_force()
        except Exception:
            pass

    def _tray_search(self) -> None:
        # Search should bring up overlay (if enabled) and focus the main search box
        try:
            if bool(self.settings.get("overlay_enabled", True)):
                if str(self._overlay.state()) == "withdrawn":
                    self._overlay.show()
        except Exception:
            pass
        self._tray_show()
        try:
            self.search_entry.focus_set()
            self.search_entry.selection_range(0, tk.END)
        except Exception:
            pass

    def _tray_open(self) -> None:
        # Open should simply show the main window
        self._tray_show()

    def _tray_quit(self) -> None:
        try:
            self.shutdown()
        except Exception:
            pass
        try:
            self.root.destroy()
        except Exception:
            pass

    # ---------------- Status ----------------

    def _tray_poll_status(self, remaining_ms: int = 5000) -> None:
        """Poll tray diagnostics so status isn't marked failed prematurely (tray starts on a worker thread)."""
        try:
            if self._tray_mgr and hasattr(self._tray_mgr, "get_diagnostics"):
                self._tray_diag.update(self._tray_mgr.get_diagnostics())
                success = bool(self._tray_diag.get("success"))
                failures = (self._tray_diag.get("win32_failures") or "").strip()
                if success:
                    self._tray_status = "Tray: On"
                    return
                if failures:
                    self._tray_status = "Tray: Failed"
                    return
        except Exception:
            pass

        if remaining_ms <= 0:
            # Timed out waiting for success; leave as failed if we have any evidence, else keep as Starting
            if (self._tray_diag.get("win32_failures") or "").strip():
                self._tray_status = "Tray: Failed"
            return

        try:
            self.root.after(250, lambda: self._tray_poll_status(remaining_ms - 250))
        except Exception:
            pass
    def _update_status(self) -> None:
        chrome = "OK" if self._chrome_exe else "Not found"
        profiles_count = len(self._profiles)
        showing = len(self._filtered)
        parts = [
            f"Chrome: {chrome}",
            f"Profiles: {profiles_count}",
            f"Showing: {showing}",
            getattr(self, "_hotkey_status", "Hotkey: ?"),
            "Overlay: " + ("On" if bool(self.settings.get("overlay_enabled", True)) else "Off"),
            getattr(self, "_tray_status", "Tray: N/A"),
        ]
        self.status.config(text="  |  ".join(parts))

    def shutdown(self) -> None:
        if self._tray_mgr is not None:
            try:
                self._tray_mgr.stop()
            except Exception:
                pass
        if self._hk_mgr:
            try:
                self._hk_mgr.unregister_all()
            except Exception:
                pass
        try:
            self._overlay.destroy()
        except Exception:
            pass
