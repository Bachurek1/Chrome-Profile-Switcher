"""System tray integration (Windows native, no external deps).

Implements a basic notification area (tray) icon using Win32 APIs via ctypes.

This avoids optional dependencies like pystray/PIL and works reliably when frozen
with PyInstaller.

Non-Windows platforms will report unavailable.
"""

from __future__ import annotations

import os
import sys
import threading
import ctypes
from ctypes import wintypes
from typing import Callable, Optional, Tuple



# --- Win32 callback prototype (some Python builds omit wintypes.WNDPROC / wintypes.LRESULT) ---
if hasattr(wintypes, "LRESULT"):
    _LRESULT = wintypes.LRESULT  # type: ignore
else:
    # LRESULT is pointer-sized signed integer
    _LRESULT = ctypes.c_longlong if ctypes.sizeof(ctypes.c_void_p) == 8 else ctypes.c_long

WNDPROC = ctypes.WINFUNCTYPE(_LRESULT, wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM)


# --- Compatibility: some Python builds omit these aliases ---
for _name in ("HICON", "HCURSOR", "HBRUSH", "HINSTANCE", "HMENU"):
    if not hasattr(wintypes, _name):
        setattr(wintypes, _name, wintypes.HANDLE)
# Pointer-sized integer used by some APIs
if not hasattr(wintypes, "UINT_PTR"):
    wintypes.UINT_PTR = ctypes.c_size_t  # type: ignore
# Some builds omit LPCRECT; we only pass NULL so void* is fine
if not hasattr(wintypes, "LPCRECT"):
    wintypes.LPCRECT = ctypes.c_void_p  # type: ignore
# ATOM fallback
if not hasattr(wintypes, "ATOM"):
    wintypes.ATOM = wintypes.WORD  # type: ignore


def _resource_path(rel: str) -> str:
    """Resolve resource path in source and PyInstaller one-folder/one-file."""
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        return os.path.join(sys._MEIPASS, rel)
    return os.path.join(os.path.dirname(os.path.dirname(__file__)), rel)


# Win32 constants
WM_DESTROY = 0x0002
WM_CLOSE = 0x0010
WM_COMMAND = 0x0111
WM_USER = 0x0400
WM_APP = 0x8000
WM_RBUTTONUP = 0x0205
WM_LBUTTONUP = 0x0202

TPM_LEFTALIGN = 0x0000
TPM_RIGHTBUTTON = 0x0002
TPM_BOTTOMALIGN = 0x0020

NIM_ADD = 0x00000000
NIM_MODIFY = 0x00000001
NIM_DELETE = 0x00000002

NIF_MESSAGE = 0x00000001
NIF_ICON = 0x00000002
NIF_TIP = 0x00000004

IMAGE_ICON = 1
LR_LOADFROMFILE = 0x0010
LR_DEFAULTSIZE = 0x0040
LR_SHARED = 0x8000

SW_HIDE = 0
SW_SHOW = 5

IDI_APPLICATION = 32512

# Our tray callback message
TRAY_CALLBACK_MSG = WM_APP + 1

# Menu command IDs
CMD_SEARCH = 1002
CMD_OPEN = 1003
CMD_SETTINGS = 1004
CMD_DIAGNOSTICS = 1005
CMD_QUIT = 1006


class POINT(ctypes.Structure):
    _fields_ = [("x", wintypes.LONG), ("y", wintypes.LONG)]


class WNDCLASSW(ctypes.Structure):
    _fields_ = [
        ("style", wintypes.UINT),
        ("lpfnWndProc", WNDPROC),
        ("cbClsExtra", ctypes.c_int),
        ("cbWndExtra", ctypes.c_int),
        ("hInstance", wintypes.HINSTANCE),
        ("hIcon", wintypes.HICON),
        ("hCursor", wintypes.HCURSOR),
        ("hbrBackground", wintypes.HBRUSH),
        ("lpszMenuName", wintypes.LPCWSTR),
        ("lpszClassName", wintypes.LPCWSTR),
    ]


class NOTIFYICONDATAW(ctypes.Structure):
    _fields_ = [
        ("cbSize", wintypes.DWORD),
        ("hWnd", wintypes.HWND),
        ("uID", wintypes.UINT),
        ("uFlags", wintypes.UINT),
        ("uCallbackMessage", wintypes.UINT),
        ("hIcon", wintypes.HICON),
        ("szTip", wintypes.WCHAR * 128),
        ("dwState", wintypes.DWORD),
        ("dwStateMask", wintypes.DWORD),
        ("szInfo", wintypes.WCHAR * 256),
        ("uTimeoutOrVersion", wintypes.UINT),
        ("szInfoTitle", wintypes.WCHAR * 64),
        ("dwInfoFlags", wintypes.DWORD),
        ("guidItem", ctypes.c_byte * 16),
        ("hBalloonIcon", wintypes.HICON),
    ]


_shell32 = ctypes.WinDLL("shell32", use_last_error=True)
_user32 = ctypes.WinDLL("user32", use_last_error=True)
_kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)


# Function prototypes we use
Shell_NotifyIconW = _shell32.Shell_NotifyIconW
Shell_NotifyIconW.argtypes = (wintypes.DWORD, ctypes.POINTER(NOTIFYICONDATAW))
Shell_NotifyIconW.restype = wintypes.BOOL

CreatePopupMenu = _user32.CreatePopupMenu
CreatePopupMenu.restype = wintypes.HMENU

AppendMenuW = _user32.AppendMenuW
AppendMenuW.argtypes = (wintypes.HMENU, wintypes.UINT, wintypes.UINT_PTR, wintypes.LPCWSTR)
AppendMenuW.restype = wintypes.BOOL

TrackPopupMenu = _user32.TrackPopupMenu
TrackPopupMenu.argtypes = (wintypes.HMENU, wintypes.UINT, ctypes.c_int, ctypes.c_int, ctypes.c_int, wintypes.HWND, wintypes.LPCRECT)
TrackPopupMenu.restype = wintypes.BOOL

SetForegroundWindow = _user32.SetForegroundWindow
SetForegroundWindow.argtypes = (wintypes.HWND,)
SetForegroundWindow.restype = wintypes.BOOL

GetCursorPos = _user32.GetCursorPos
GetCursorPos.argtypes = (ctypes.POINTER(POINT),)
GetCursorPos.restype = wintypes.BOOL

PostMessageW = _user32.PostMessageW
PostMessageW.argtypes = (wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM)
PostMessageW.restype = wintypes.BOOL

DestroyMenu = _user32.DestroyMenu
DestroyMenu.argtypes = (wintypes.HMENU,)
DestroyMenu.restype = wintypes.BOOL

LoadImageW = _user32.LoadImageW
LoadImageW.argtypes = (wintypes.HINSTANCE, wintypes.LPCWSTR, wintypes.UINT, ctypes.c_int, ctypes.c_int, wintypes.UINT)
LoadImageW.restype = wintypes.HANDLE

LoadIconW = _user32.LoadIconW
LoadIconW.argtypes = (wintypes.HINSTANCE, wintypes.LPCWSTR)
LoadIconW.restype = wintypes.HICON

RegisterClassW = _user32.RegisterClassW
RegisterClassW.argtypes = (ctypes.POINTER(WNDCLASSW),)
RegisterClassW.restype = wintypes.ATOM

CreateWindowExW = _user32.CreateWindowExW
CreateWindowExW.argtypes = (
    wintypes.DWORD, wintypes.LPCWSTR, wintypes.LPCWSTR, wintypes.DWORD,
    ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
    wintypes.HWND, wintypes.HMENU, wintypes.HINSTANCE, wintypes.LPVOID
)
CreateWindowExW.restype = wintypes.HWND

DefWindowProcW = _user32.DefWindowProcW
DefWindowProcW.argtypes = (wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM)
DefWindowProcW.restype = _LRESULT

DestroyWindow = _user32.DestroyWindow
DestroyWindow.argtypes = (wintypes.HWND,)
DestroyWindow.restype = wintypes.BOOL

GetMessageW = _user32.GetMessageW
GetMessageW.argtypes = (ctypes.POINTER(wintypes.MSG), wintypes.HWND, wintypes.UINT, wintypes.UINT)
GetMessageW.restype = wintypes.BOOL

TranslateMessage = _user32.TranslateMessage
TranslateMessage.argtypes = (ctypes.POINTER(wintypes.MSG),)
TranslateMessage.restype = wintypes.BOOL

DispatchMessageW = _user32.DispatchMessageW
DispatchMessageW.argtypes = (ctypes.POINTER(wintypes.MSG),)
DispatchMessageW.restype = _LRESULT

PostQuitMessage = _user32.PostQuitMessage
PostQuitMessage.argtypes = (ctypes.c_int,)
PostQuitMessage.restype = None

GetModuleHandleW = _kernel32.GetModuleHandleW
GetModuleHandleW.argtypes = (wintypes.LPCWSTR,)
GetModuleHandleW.restype = wintypes.HINSTANCE


class TrayManager:
    def __init__(
        self,
        title: str,
        on_show: Callable[[], None],
        on_search: Callable[[], None],
        on_settings: Callable[[], None],
        on_open: Callable[[], None],
        on_diagnostics: Callable[[], None],
        on_quit: Callable[[], None],
    ):
        self.title = title
        self.on_show = on_show
        self.on_search = on_search
        self.on_settings = on_settings
        self.on_open = on_open
        self.on_diagnostics = on_diagnostics
        self.on_quit = on_quit

        self._thread: Optional[threading.Thread] = None
        self._hwnd: Optional[int] = None
        self._nid: Optional[NOTIFYICONDATAW] = None
        self._class_name = "ChromeProfileSwitcherTrayWindow"

        # Keep WNDPROC callback alive (ctypes callbacks must be strongly referenced)
        self._wndproc_ref = None

        # Diagnostics (must be queryable even if tray fails)
        self._failures: list[str] = []
        self._diag = {
            "attempted": False,
            "success": False,
            "hwnd": "",
            "last_error": "",
            "win32_failures": "",
            "start_thread": "",
            "tray_thread": "",
        }

        self.available, self.unavailable_reason = self._check_available()

    def _check_available(self) -> Tuple[bool, Optional[str]]:
        if os.name != "nt":
            return False, "Windows only"
        return True, None

    def start(self) -> bool:
        if not self.available:
            self._diag["attempted"] = True
            self._diag["success"] = False
            self._diag["start_thread"] = threading.current_thread().name
            self._diag["tray_thread"] = ""
            return False
        if self._thread and self._thread.is_alive():
            return True
        self._diag["attempted"] = True
        self._diag["start_thread"] = threading.current_thread().name
        self._thread = threading.Thread(target=self._run, daemon=True, name="TrayThread")
        self._diag["tray_thread"] = self._thread.name
        self._thread.start()
        return True

    def stop(self) -> None:
        try:
            if self._hwnd:
                PostMessageW(wintypes.HWND(self._hwnd), WM_CLOSE, 0, 0)
        except Exception:
            pass

    # ---------------- Internal ----------------
    def _run(self) -> None:
        try:
            self._diag["tray_thread"] = threading.current_thread().name
            self._create_window_and_icon()
            self._message_loop()
        except Exception:
            import traceback as _tb
            # Record failure details for diagnostics, but keep the app alive
            try:
                self._failures.append("exception:" + _tb.format_exc().splitlines()[-1])
                self._diag["success"] = False
            except Exception:
                pass
            try:
                self._remove_icon()
            except Exception:
                pass

    def _create_window_and_icon(self) -> None:
        hinst = GetModuleHandleW(None)

        def _wndproc_impl(hwnd, msg, wparam, lparam):
            try:
                if msg == TRAY_CALLBACK_MSG:
                    # lparam contains the mouse message
                    if lparam == WM_LBUTTONUP:
                        self._safe_call(self.on_open)
                    elif lparam == WM_RBUTTONUP:
                        self._show_menu(hwnd)
                    return 0
                elif msg == WM_COMMAND:
                    cmd_id = wparam & 0xFFFF
                    if cmd_id == CMD_SEARCH:
                        self._safe_call(self.on_search)
                    elif cmd_id == CMD_OPEN:
                        self._safe_call(self.on_open)
                    elif cmd_id == CMD_SETTINGS:
                        self._safe_call(self.on_settings)
                    elif cmd_id == CMD_DIAGNOSTICS:
                        self._safe_call(self.on_diagnostics)
                    elif cmd_id == CMD_QUIT:
                        # Let app decide shutdown; then close tray
                        self._safe_call(self.on_quit)
                        PostMessageW(hwnd, WM_CLOSE, 0, 0)
                    return 0
                elif msg == WM_CLOSE:
                    self._remove_icon()
                    DestroyWindow(hwnd)
                    return 0
                elif msg == WM_DESTROY:
                    PostQuitMessage(0)
                    return 0
            except Exception:
                pass
            return DefWindowProcW(hwnd, msg, wparam, lparam)
        # Create callback and keep a strong reference on self to avoid GC crashes
        self._wndproc_ref = WNDPROC(_wndproc_impl)

        wc = WNDCLASSW()
        wc.lpfnWndProc = self._wndproc_ref
        wc.lpszClassName = self._class_name
        wc.hInstance = hinst
        wc.hIcon = LoadIconW(None, wintypes.LPCWSTR(IDI_APPLICATION))
        wc.hCursor = LoadIconW(None, wintypes.LPCWSTR(IDI_APPLICATION))
        wc.hbrBackground = 0

        atom = RegisterClassW(ctypes.byref(wc))
        if not atom:
            # ERROR_CLASS_ALREADY_EXISTS (1410) is benign
            err = ctypes.get_last_error()
            if err != 1410:
                self._record_fail("RegisterClassW")

        hwnd = CreateWindowExW(
            0,
            self._class_name,
            self.title,
            0,
            0, 0, 0, 0,
            0, 0,
            hinst,
            None,
        )
        if not hwnd:
            self._record_fail("CreateWindowExW")
            raise RuntimeError("CreateWindowExW failed")
        self._hwnd = int(hwnd)

        # Load icon from assets/favicon.ico if present
        icon_path = _resource_path("assets\\favicon.ico")
        hicon = None
        if os.path.exists(icon_path):
            hicon = LoadImageW(None, icon_path, IMAGE_ICON, 0, 0, LR_LOADFROMFILE | LR_DEFAULTSIZE)
            if not hicon:
                self._record_fail("LoadImageW")
        if not hicon:
            hicon = LoadIconW(None, wintypes.LPCWSTR(IDI_APPLICATION))

        nid = NOTIFYICONDATAW()
        nid.cbSize = ctypes.sizeof(NOTIFYICONDATAW)
        nid.hWnd = hwnd
        nid.uID = 1
        nid.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP
        nid.uCallbackMessage = TRAY_CALLBACK_MSG
        nid.hIcon = wintypes.HICON(hicon)
        tip = (self.title or "Chrome Profile Switcher")[:127]
        nid.szTip = tip
        self._nid = nid

        ok = Shell_NotifyIconW(NIM_ADD, ctypes.byref(nid))
        if not ok:
            self._record_fail("Shell_NotifyIconW(NIM_ADD)")
            raise RuntimeError("Shell_NotifyIconW add failed")
        self._diag["success"] = True

    def _remove_icon(self) -> None:
        if self._nid is not None:
            try:
                Shell_NotifyIconW(NIM_DELETE, ctypes.byref(self._nid))
            except Exception:
                pass
            self._nid = None

    def _message_loop(self) -> None:
        msg = wintypes.MSG()
        while GetMessageW(ctypes.byref(msg), 0, 0, 0) != 0:
            TranslateMessage(ctypes.byref(msg))
            DispatchMessageW(ctypes.byref(msg))

    def _show_menu(self, hwnd) -> None:
        menu = CreatePopupMenu()
        try:
            AppendMenuW(menu, 0, CMD_SEARCH, "Search")
            AppendMenuW(menu, 0, CMD_OPEN, "Open")
            AppendMenuW(menu, 0, CMD_QUIT, "Quit")

            pt = POINT()
            GetCursorPos(ctypes.byref(pt))
            # Required: SetForegroundWindow before TrackPopupMenu or menu can vanish immediately
            SetForegroundWindow(hwnd)
            TrackPopupMenu(menu, TPM_LEFTALIGN | TPM_BOTTOMALIGN | TPM_RIGHTBUTTON, pt.x, pt.y, 0, hwnd, None)
            # Post a benign message to make Windows dismiss menu correctly
            PostMessageW(hwnd, 0, 0, 0)
        finally:
            try:
                DestroyMenu(menu)
            except Exception:
                pass

    def _safe_call(self, fn: Callable[[], None]) -> None:
        try:
            fn()
        except Exception:
            pass

    def _record_fail(self, where: str) -> None:
        try:
            err = ctypes.get_last_error()
        except Exception:
            err = 0
        try:
            self._diag["last_error"] = str(err)
            self._failures.append(f"{where}={err}")
            self._diag["win32_failures"] = "; ".join(self._failures)
        except Exception:
            pass

    def get_diagnostics(self) -> dict:
        # Return a copy so callers can't mutate internal state
        try:
            d = dict(self._diag)
            d["hwnd"] = str(self._hwnd or "")
            d["win32_failures"] = "; ".join(self._failures)
            return d
        except Exception:
            return {}


def tray_selftest() -> tuple[bool, str]:
    """Attempt a minimal Win32 call to validate tray module loads.

    Returns (ok, details). This does NOT create a tray icon; it just
    verifies the core DLLs and symbols are callable.
    """
    try:
        # simple symbol call: GetModuleHandleW(None)
        h = _kernel32.GetModuleHandleW(None)
        if not h:
            return False, f"GetModuleHandleW failed: {ctypes.get_last_error()}"
        return True, "tray module loaded OK"
    except Exception as e:
        import traceback as _tb
        return False, _tb.format_exc()
