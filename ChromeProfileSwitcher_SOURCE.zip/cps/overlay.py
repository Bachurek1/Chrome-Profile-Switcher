import tkinter as tk
from tkinter import ttk
from typing import Callable, List, Optional

class QuickOverlay(tk.Toplevel):
    """
    Lightweight overlay:
    - Appears centered near the top of the active monitor.
    - Has a search box + results list.
    - Enter opens selected, Esc hides.
    """
    def __init__(self, root: tk.Tk, on_query: Callable[[str], List[tuple]], on_open: Callable[[str], None], width: int = 640, max_results: int = 20):
        super().__init__(root)
        self.withdraw()
        self.overrideredirect(True)
        self.attributes("-topmost", True)
        self.configure(bg="#0b0b0b")
        self._on_query = on_query
        self._on_open = on_open
        self._max_results = max_results
        self._visible = False

        outer = ttk.Frame(self, style="Card.TFrame", padding=12)
        outer.pack(fill="both", expand=True)

        self.var = tk.StringVar()
        self.entry = ttk.Entry(outer, textvariable=self.var)
        self.entry.pack(fill="x")

        self.listbox = tk.Listbox(
            outer,
            height=max_results,
            activestyle="none",
            highlightthickness=1,
            relief="flat",
            bd=0,
            exportselection=False
        )
        self.listbox.pack(fill="both", expand=True, pady=(10, 0))

        self.entry.bind("<Escape>", lambda e: self.hide())
        self.entry.bind("<Return>", lambda e: self._open_selected())
        self.entry.bind("<KeyRelease>", lambda e: self._refresh())

        self.listbox.bind("<Escape>", lambda e: self.hide())
        self.listbox.bind("<Return>", lambda e: self._open_selected())
        self.listbox.bind("<Double-Button-1>", lambda e: self._open_selected())

        self._items: List[tuple] = []  # [(profile_dir_name, label)]
        self._width = width

        # Close rules (prevents the overlay getting stuck on screen):
        # - If the user clicks anywhere outside the search box, hide.
        # - If focus leaves the overlay (e.g. Alt+Tab / click other window), hide.
        #   (We delay the focus check slightly so internal focus moves don't instantly close it.)
        self.bind("<FocusOut>", self._on_focus_out)
        self.bind("<Button-1>", self._on_any_click, add="+")
        outer.bind("<Button-1>", self._on_any_click, add="+")
        self.listbox.bind("<Button-1>", self._on_any_click, add="+")

    def _focus_entry(self) -> None:
        """Force focus into the search entry and select its content."""
        try:
            self.lift()
        except Exception:
            pass
        try:
            self.focus_force()
        except Exception:
            pass
        try:
            self.entry.focus_force()
            self.entry.select_range(0, tk.END)
            self.entry.icursor(tk.END)
        except Exception:
            pass

    def _on_focus_out(self, _event=None) -> None:
        # Delay to let focus settle, then hide if the Entry is not focused.
        def _check():
            try:
                w = self.focus_get()
                if w is self.entry:
                    return
                self.hide()
            except Exception:
                try:
                    self.hide()
                except Exception:
                    pass

        try:
            self.after(60, _check)
        except Exception:
            pass

    def _on_any_click(self, event=None) -> None:
        # Hide if the click target is not the Entry (or a child of it).
        try:
            w = event.widget if event is not None else None
            if w is None:
                self.hide()
                return
            if w is self.entry:
                return
            # Treat clicks on internal Entry children as safe.
            parent = w
            while parent is not None:
                if parent is self.entry:
                    return
                parent = getattr(parent, "master", None)
            self.hide()
        except Exception:
            try:
                self.hide()
            except Exception:
                pass

    def show(self):
        if self._visible:
            self._focus_entry()
            return

        self._visible = True
        self.var.set("")
        self._items = []
        self._refresh()

        # Size + position
        self.update_idletasks()
        w = self._width
        h = 160 + (min(self._max_results, 20) * 22)
        h = min(h, 640)

        screen_w = self.winfo_screenwidth()
        x = int((screen_w - w) / 2)
        y = 80
        self.geometry(f"{w}x{h}+{x}+{y}")

        self.deiconify()
        self._focus_entry()

        # Some environments (and some focus transitions) need a second delayed focus push.
        try:
            self.after(10, self._focus_entry)
        except Exception:
            pass

    def hide(self):
        self._visible = False
        self.withdraw()

    def _refresh(self):
        q = self.var.get().strip()
        items = self._on_query(q)[: self._max_results]
        self._items = items
        self.listbox.delete(0, tk.END)
        for _, label in items:
            self.listbox.insert(tk.END, label)
        if items:
            self.listbox.selection_clear(0, tk.END)
            self.listbox.selection_set(0)
            self.listbox.activate(0)

    def _open_selected(self):
        if not self._items:
            return
        sel = self.listbox.curselection()
        idx = int(sel[0]) if sel else 0
        idx = max(0, min(idx, len(self._items)-1))
        profile_dir, _ = self._items[idx]
        try:
            self._on_open(profile_dir)
        finally:
            self.hide()
