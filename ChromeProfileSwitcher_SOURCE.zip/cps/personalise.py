import tkinter as tk
from tkinter import ttk, messagebox
from typing import Any, Callable, Dict, List, Optional, Union, Tuple

from cps.chrome_profiles import ChromeProfile
from cps.ui_styles import apply_theme, theme_colors

def _portal_list(settings: Dict[str, Any]) -> List[Dict[str, str]]:
    portals = settings.get("portal_urls")
    if isinstance(portals, list):
        out = []
        for p in portals:
            if isinstance(p, dict):
                name = str(p.get("name", "")).strip()
                url = str(p.get("url", "")).strip()
                if name and url:
                    out.append({"name": name, "url": url})
        return out
    return []

def _set_portal_list(settings: Dict[str, Any], portals: List[Dict[str, str]]) -> None:
    settings["portal_urls"] = [{"name": p["name"], "url": p["url"]} for p in portals]

def _portal_name_to_url(settings: Dict[str, Any]) -> Dict[str, str]:
    return {p["name"]: p["url"] for p in _portal_list(settings)}

class PersonaliseDialog(tk.Toplevel):
    def __init__(
        self,
        parent: tk.Tk,
        settings: Dict[str, Any],
        profiles: Union[List[str], List[ChromeProfile]],
        hotkey_status_text: str,
        test_hotkey_callback: Optional[Callable[[], None]] = None,
        validate_hotkey_callback: Optional[Callable[[str], bool]] = None,
        set_hotkey_callback: Optional[Callable[[str], bool]] = None,
        on_applied: Optional[Callable[[], None]] = None
    ):
        super().__init__(parent)
        self.parent = parent
        self.settings = settings
        self.on_applied = on_applied
        self.test_hotkey_callback = test_hotkey_callback
        self.validate_hotkey_callback = validate_hotkey_callback
        self.set_hotkey_callback = set_hotkey_callback
        self.hotkey_status_text = hotkey_status_text
        self._pending_hotkey = str(self.settings.get("hotkey", "")).strip()

        self.title("Settings / Personalise")
        self.resizable(True, True)
        self.geometry("860x520")

        # Use current theme while dialog is open (consistent visuals)
        ui = settings.get("ui", {}) if isinstance(settings.get("ui"), dict) else {}
        apply_theme(self, str(ui.get("theme", "Dark")), str(ui.get("accent", "Orange")))
        self.colors = theme_colors(str(ui.get("theme", "Dark")), str(ui.get("accent", "Orange")))

        # Normalize profiles input
        self._profiles: List[ChromeProfile] = []
        if profiles and isinstance(profiles[0], ChromeProfile):  # type: ignore[index]
            self._profiles = list(profiles)  # type: ignore[assignment]
        else:
            # Only dir names provided - make placeholders
            self._profiles = [ChromeProfile(dir_name=str(p), display_name=str(p), path="") for p in profiles]  # type: ignore[arg-type]

        # Sort A-Z by display name (as requested)
        self._profiles.sort(key=lambda p: (p.display_name or p.dir_name).casefold())

        self._build_ui()
        self.transient(parent)
        self.grab_set()
        self.protocol("WM_DELETE_WINDOW", self._cancel)

    def _build_ui(self) -> None:
        c = self.colors

        outer = ttk.Frame(self, padding=12)
        outer.pack(fill="both", expand=True)

        self.nb = ttk.Notebook(outer)
        self.nb.pack(fill="both", expand=True)

        self.tab_appearance = ttk.Frame(self.nb, padding=12)
        self.tab_portals = ttk.Frame(self.nb, padding=12)
        self.tab_per_profile = ttk.Frame(self.nb, padding=12)

        self.nb.add(self.tab_appearance, text="Appearance")
        self.nb.add(self.tab_portals, text="Portals")
        self.nb.add(self.tab_per_profile, text="Per-profile")
        self.tab_io = ttk.Frame(self.nb)
        self.nb.add(self.tab_io, text="Import/Export")

        self._build_appearance_tab()
        self._build_portals_tab()
        self._build_per_profile_tab()
        self._build_io_tab()

        # Footer
        footer = ttk.Frame(outer)
        footer.pack(fill="x", pady=(10, 0))

        ttk.Button(footer, text="Apply", style="Accent.TButton", command=self._apply).pack(side="right")
        ttk.Button(footer, text="Cancel", style="Ghost.TButton", command=self._cancel).pack(side="right", padx=(0, 10))

    def _build_appearance_tab(self) -> None:
        ui = self.settings.get("ui", {}) if isinstance(self.settings.get("ui"), dict) else {}
        self.theme_var = tk.StringVar(value=str(ui.get("theme", "Dark")))
        self.accent_var = tk.StringVar(value=str(ui.get("accent", "Orange")))
        self.default_portal_var = tk.StringVar(value=str(self.settings.get("default_portal", "")))
        self.global_default_portal_name_var = tk.StringVar(value=str(self.settings.get("global_default_portal_name", "")))
        tray_cfg = self.settings.get("tray") if isinstance(self.settings.get("tray"), dict) else {}
        self.tray_enabled_var = tk.BooleanVar(value=bool(tray_cfg.get("enabled", True)) if isinstance(tray_cfg, dict) else True)

        row = ttk.Frame(self.tab_appearance)
        row.pack(fill="x")

        ttk.Label(row, text="Theme:", style="Muted.TLabel").grid(row=0, column=0, sticky="w", padx=(0, 8), pady=(0, 10))
        self.theme_combo = ttk.Combobox(row, state="readonly", values=["Dark", "Light", "Midnight", "High Contrast"], textvariable=self.theme_var, width=20)
        self.theme_combo.grid(row=0, column=1, sticky="w", pady=(0, 10))
        self.theme_combo.bind("<<ComboboxSelected>>", self._preview_theme)

        ttk.Label(row, text="Accent:", style="Muted.TLabel").grid(row=0, column=2, sticky="w", padx=(18, 8), pady=(0, 10))
        self.accent_combo = ttk.Combobox(row, state="readonly", values=["Orange", "Blue", "Green", "Purple", "Red", "Yellow"], textvariable=self.accent_var, width=18)
        self.accent_combo.grid(row=0, column=3, sticky="w", pady=(0, 10))
        self.accent_combo.bind("<<ComboboxSelected>>", self._preview_theme)

        ttk.Label(self.tab_appearance, text="Global default portal URL:", style="Muted.TLabel").pack(anchor="w", pady=(8, 4))
        ttk.Entry(self.tab_appearance, textvariable=self.default_portal_var).pack(fill="x")

        ttk.Label(self.tab_appearance, text="Global default portal (by name):", style="Muted.TLabel").pack(anchor="w", pady=(10, 4))
        names = sorted([p.get("name","") for p in _portal_list(self.settings) if isinstance(p, dict) and p.get("name")], key=lambda s: str(s).casefold())
        self.global_default_portal_name_combo = ttk.Combobox(self.tab_appearance, state="readonly", values=[""] + names, textvariable=self.global_default_portal_name_var)
        self.global_default_portal_name_combo.pack(fill="x")
        ttk.Label(
            self.tab_appearance,
            text="Tip: If set, profiles without per-profile mappings will use this named portal. Otherwise they use the URL above.",
            style="Muted.TLabel"
        ).pack(anchor="w", pady=(6, 0))

        # Hotkey section
        hk = ttk.Frame(self.tab_appearance)
        hk.pack(fill="x", pady=(16, 0))

        ttk.Label(hk, text="Overlay hotkey:", style="Muted.TLabel").grid(row=0, column=0, sticky="w")
        self._hotkey_value = tk.StringVar(value=str(self.settings.get("hotkey", "")).strip())
        ttk.Label(hk, textvariable=self._hotkey_value).grid(row=0, column=1, sticky="w", padx=(8, 0))

        ttk.Label(hk, text="Status:", style="Muted.TLabel").grid(row=1, column=0, sticky="w", pady=(6, 0))
        ttk.Label(hk, text=self.hotkey_status_text).grid(row=1, column=1, sticky="w", padx=(8, 0), pady=(6, 0))

        if self.test_hotkey_callback is not None:
            ttk.Button(hk, text="Test Overlay Hotkey", style="Ghost.TButton", command=self._test_hotkey).grid(row=0, column=2, rowspan=2, padx=(18, 0))

        if self.set_hotkey_callback is not None or self.validate_hotkey_callback is not None:
            ttk.Button(hk, text="Change Hotkey…", style="Primary.TButton", command=self._change_hotkey).grid(row=0, column=3, rowspan=2, padx=(10, 0))
            ttk.Label(hk, text="(Ctrl+Shift+Alt + A–Z / 0–9 / F1–F12)", style="Muted.TLabel").grid(row=2, column=1, columnspan=3, sticky="w", padx=(8,0), pady=(6,0))

        tray_row = ttk.Frame(self.tab_appearance)
        tray_row.pack(fill="x", pady=(14, 0))
        tray_cb = ttk.Checkbutton(tray_row, text="Enable system tray icon", variable=self.tray_enabled_var)
        tray_cb.pack(anchor="w")
        ttk.Label(
            tray_row,
            text="Right-click the tray icon for Search, Open, Settings, Diagnostics and Quit.",
            style="Muted.TLabel"
        ).pack(anchor="w", pady=(4, 0))

    def _build_portals_tab(self) -> None:
        c = self.colors
        self.portals: List[Dict[str, str]] = _portal_list(self.settings)

        top = ttk.Frame(self.tab_portals)
        top.pack(fill="both", expand=True)

        left = ttk.Frame(top, style="Card.TFrame", padding=10)
        left.pack(side="left", fill="both", expand=True, padx=(0, 10))
        right = ttk.Frame(top, style="Card.TFrame", padding=10)
        right.pack(side="left", fill="both", expand=True)

        ttk.Label(left, text="Named portals").pack(anchor="w")
        self.portal_listbox = tk.Listbox(left, activestyle="none", exportselection=False, height=14)
        self.portal_listbox.pack(fill="both", expand=True, pady=(8, 0))
        self._style_listbox(self.portal_listbox)
        self.portal_listbox.bind("<<ListboxSelect>>", self._on_portal_select)

        form = ttk.Frame(right)
        form.pack(fill="x")

        ttk.Label(form, text="Name:", style="Muted.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(form, text="URL:", style="Muted.TLabel").grid(row=1, column=0, sticky="w", pady=(10, 0))

        self.portal_name_var = tk.StringVar()
        self.portal_url_var = tk.StringVar()

        ttk.Entry(form, textvariable=self.portal_name_var).grid(row=0, column=1, sticky="ew", padx=(10, 0))
        ttk.Entry(form, textvariable=self.portal_url_var).grid(row=1, column=1, sticky="ew", padx=(10, 0), pady=(10, 0))
        form.columnconfigure(1, weight=1)

        btns = ttk.Frame(right)
        btns.pack(fill="x", pady=(14, 0))

        ttk.Button(btns, text="Add", style="Ghost.TButton", command=self._portal_add).pack(side="left")
        ttk.Button(btns, text="Update", style="Ghost.TButton", command=self._portal_update).pack(side="left", padx=(10, 0))
        ttk.Button(btns, text="Remove", style="Ghost.TButton", command=self._portal_remove).pack(side="left", padx=(10, 0))

        self._refresh_portal_list()

    def _build_per_profile_tab(self) -> None:
        self.portal_name_map = _portal_name_to_url(self.settings)

        top = ttk.Frame(self.tab_per_profile)
        top.pack(fill="both", expand=True)

        left = ttk.Frame(top, style="Card.TFrame", padding=10)
        left.pack(side="left", fill="y", padx=(0, 10))
        right = ttk.Frame(top, style="Card.TFrame", padding=10)
        right.pack(side="left", fill="both", expand=True)

        ttk.Label(left, text="Profiles").pack(anchor="w")
        self.profile_listbox = tk.Listbox(left, activestyle="none", exportselection=False, height=18, width=28)
        self.profile_listbox.pack(fill="y", expand=False, pady=(8, 0))
        self._style_listbox(self.profile_listbox)
        self.profile_listbox.bind("<<ListboxSelect>>", self._on_profile_select)

        self.profile_index: List[ChromeProfile] = []
        for p in self._profiles:
            self.profile_index.append(p)
            self.profile_listbox.insert(tk.END, p.display_name)

        ttk.Label(right, text="Default portal (by name):", style="Muted.TLabel").pack(anchor="w")
        self.per_name_var = tk.StringVar()
        self.per_name_combo = ttk.Combobox(right, state="readonly", textvariable=self.per_name_var, values=self._portal_names(), width=40)
        self.per_name_combo.pack(fill="x", pady=(4, 12))

        ttk.Label(right, text="Override URL (advanced):", style="Muted.TLabel").pack(anchor="w")
        self.per_override_var = tk.StringVar()
        ttk.Entry(right, textvariable=self.per_override_var).pack(fill="x", pady=(4, 0))

        ttk.Button(right, text="Save mapping", style="Accent.TButton", command=self._save_mapping).pack(fill="x", pady=(14, 0))

        ttk.Label(
            right,
            text="Tip: Leave override blank to use the chosen named portal.\nLeave both blank to fall back to the global default portal.",
            style="Muted.TLabel"
        ).pack(anchor="w", pady=(12, 0))

        # Select first by default
        if self.profile_index:
            self.profile_listbox.selection_set(0)
            self.profile_listbox.activate(0)
            self._load_mapping_for(self.profile_index[0])

    def _build_io_tab(self) -> None:
        from tkinter import filedialog, messagebox  # noqa: F401
        frm = ttk.Frame(self.tab_io)
        frm.pack(fill="both", expand=True, padx=14, pady=14)

        ttk.Label(frm, text="Import / Export Settings", style="Section.TLabel").pack(anchor="w")
        ttk.Label(
            frm,
            text=(
                "Export your current configuration to JSON, or import from a JSON file. "
                "Import performs a safe merge (adds new keys, preserves defaults)."
            ),
            style="Muted.TLabel",
            wraplength=560,
            justify="left",
        ).pack(anchor="w", pady=(6, 12))

        btns = ttk.Frame(frm)
        btns.pack(anchor="w")

        ttk.Button(btns, text="Export…", style="Ghost.TButton", command=self._export_settings).pack(side="left")
        ttk.Button(btns, text="Import…", style="Ghost.TButton", command=self._import_settings).pack(side="left", padx=(10, 0))

        self._io_status = tk.StringVar(value="")
        ttk.Label(frm, textvariable=self._io_status, style="Muted.TLabel").pack(anchor="w", pady=(10, 0))

    def _export_settings(self) -> None:
        from tkinter import filedialog, messagebox
        import json

        path = filedialog.asksaveasfilename(
            title="Export settings",
            defaultextension=".json",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")]
        )
        if not path:
            return
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(self.settings, f, indent=2, ensure_ascii=False)
            self._io_status.set(f"Exported to: {path}")
        except Exception as e:
            messagebox.showerror("Export failed", str(e))

    def _import_settings(self) -> None:
        from tkinter import filedialog, messagebox
        import json
        from cps.settings import default_settings, save_settings
        from cps.settings_io import merge_into_settings

        path = filedialog.askopenfilename(
            title="Import settings",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")]
        )
        if not path:
            return
        try:
            with open(path, "r", encoding="utf-8") as f:
                incoming = json.load(f)
            if not isinstance(incoming, dict):
                raise ValueError("Imported file must contain a JSON object (a JSON dictionary).")

            merge_into_settings(self.settings, incoming, default_settings())
            save_settings(self.settings)

            # Refresh visible hotkey field if present
            try:
                self._hotkey_value.set(str(self.settings.get("hotkey", "")).strip())
            except Exception:
                pass

            self._io_status.set(f"Imported from: {path} (merged)")
            messagebox.showinfo("Imported", "Settings imported successfully. Click Apply to re-theme and refresh.")
        except Exception as e:
            messagebox.showerror("Import failed", str(e))


    def _style_listbox(self, lb: tk.Listbox) -> None:
        c = self.colors
        lb.configure(
            bg=c["panel"],
            fg=c["fg"],
            selectbackground=c["sel_bg"],
            selectforeground=c["sel_fg"],
            highlightthickness=1,
            highlightbackground=c["border"],
            highlightcolor=c["border"],
            bd=0,
            relief="flat"
        )

    def _portal_names(self) -> List[str]:
        names = [p["name"] for p in _portal_list(self.settings)]
        names.sort(key=lambda s: s.casefold())
        return [""] + names

    def _preview_theme(self, _event=None) -> None:
        # Apply preview to the dialog only
        apply_theme(self, self.theme_var.get(), self.accent_var.get())
        self.colors = theme_colors(self.theme_var.get(), self.accent_var.get())
        # re-style listboxes for the preview
        try:
            self._style_listbox(self.portal_listbox)
            self._style_listbox(self.profile_listbox)
        except Exception:
            pass

    def _change_hotkey(self) -> None:
        """Capture Ctrl+Shift+Alt+<key> and save to settings (after validation)."""
        win = tk.Toplevel(self)
        win.title("Set Hotkey")
        win.transient(self)
        win.grab_set()
        win.resizable(False, False)

        frm = ttk.Frame(win, padding=14)
        frm.pack(fill="both", expand=True)

        msg = ttk.Label(frm, text="Press CTRL + SHIFT + ALT + a key (A–Z, 0–9, F1–F12).", style="Sub.TLabel")
        msg.pack(anchor="w")

        current = ttk.Label(frm, text=f"Current: {self._hotkey_value.get()}", style="Muted.TLabel")
        current.pack(anchor="w", pady=(6, 0))

        status = tk.StringVar(value="Waiting for key press…")
        status_lbl = ttk.Label(frm, textvariable=status, style="Muted.TLabel")
        status_lbl.pack(anchor="w", pady=(10, 0))

        allowed_f = {f"F{i}" for i in range(1, 13)}
        def _allowed_key(keysym: str) -> bool:
            ks = keysym.upper()
            if ks in allowed_f:
                return True
            if len(ks) == 1 and (ks.isalpha() or ks.isdigit()):
                return True
            return False

        # Tk state masks on Windows:
        # Shift=0x0001, Control=0x0004, Alt(Mod1)=0x20000 (common), sometimes 0x0008
        SHIFT_MASK = 0x0001
        CTRL_MASK = 0x0004
        ALT_MASKS = (0x20000, 0x0008)

        def on_key(event: tk.Event) -> None:
            state = int(getattr(event, "state", 0))
            has_shift = (state & SHIFT_MASK) != 0
            has_ctrl = (state & CTRL_MASK) != 0
            has_alt = any((state & m) != 0 for m in ALT_MASKS)

            ks = str(getattr(event, "keysym", "")).upper()

            if not (has_ctrl and has_shift and has_alt):
                status.set("Hold CTRL + SHIFT + ALT, then press a key…")
                return
            if not _allowed_key(ks):
                status.set("Key not allowed. Use A–Z, 0–9, or F1–F12.")
                return

            hotkey = f"CTRL+SHIFT+ALT+{ks}"
            # Validate/try apply
            ok = True
            if self.validate_hotkey_callback is not None:
                try:
                    ok = bool(self.validate_hotkey_callback(hotkey))
                except Exception:
                    ok = False

            if not ok:
                messagebox.showwarning("Hotkey in use", f"{hotkey} could not be registered.\nTry another key.")
                status.set("Pick another key…")
                return

            # Update pending and label immediately; actual save/re-register happens on Apply
            self._pending_hotkey = hotkey
            self._hotkey_value.set(hotkey)
            status.set(f"Captured: {hotkey}")
            win.after(350, win.destroy)

        win.bind("<KeyPress>", on_key)
        win.focus_force()

        ttk.Button(frm, text="Cancel", style="Ghost.TButton", command=win.destroy).pack(anchor="e", pady=(14, 0))


    def _test_hotkey(self) -> None:
        if not self.test_hotkey_callback:
            return
        try:
            self.test_hotkey_callback()
            messagebox.showinfo("Test", "Overlay toggle invoked.\n\nIf the real hotkey still doesn't work, another app may be using the same key combo.")
        except Exception as e:
            messagebox.showerror("Test failed", str(e))

    # ----- portals tab handlers -----
    def _refresh_portal_list(self) -> None:
        self.portal_listbox.delete(0, tk.END)
        self.portals.sort(key=lambda p: p["name"].casefold())
        for p in self.portals:
            self.portal_listbox.insert(tk.END, p["name"])

        # update per-profile combo values too
        try:
            self.per_name_combo.configure(values=self._portal_names())
        except Exception:
            pass
        # update global default portal combo too
        try:
            if hasattr(self, "global_default_portal_name_combo"):
                self.global_default_portal_name_combo.configure(values=[""] + self._portal_names())
        except Exception:
            pass


    def _on_portal_select(self, _event=None) -> None:
        sel = self.portal_listbox.curselection()
        if not sel:
            return
        idx = int(sel[0])
        if 0 <= idx < len(self.portals):
            p = self.portals[idx]
            self.portal_name_var.set(p["name"])
            self.portal_url_var.set(p["url"])

    def _portal_add(self) -> None:
        name = self.portal_name_var.get().strip()
        url = self.portal_url_var.get().strip()
        if not name or not url:
            messagebox.showwarning("Missing", "Please provide both a name and a URL.")
            return
        if any(p["name"].casefold() == name.casefold() for p in self.portals):
            messagebox.showwarning("Exists", "A portal with that name already exists.")
            return
        self.portals.append({"name": name, "url": url})
        self._refresh_portal_list()

    def _portal_update(self) -> None:
        sel = self.portal_listbox.curselection()
        if not sel:
            messagebox.showwarning("Select", "Select a portal to update.")
            return
        idx = int(sel[0])
        name = self.portal_name_var.get().strip()
        url = self.portal_url_var.get().strip()
        if not name or not url:
            messagebox.showwarning("Missing", "Please provide both a name and a URL.")
            return
        # Prevent renaming collision
        for i, p in enumerate(self.portals):
            if i != idx and p["name"].casefold() == name.casefold():
                messagebox.showwarning("Exists", "Another portal already uses that name.")
                return
        self.portals[idx] = {"name": name, "url": url}
        self._refresh_portal_list()
        self.portal_listbox.selection_set(idx)

    def _portal_remove(self) -> None:
        sel = self.portal_listbox.curselection()
        if not sel:
            messagebox.showwarning("Select", "Select a portal to remove.")
            return
        idx = int(sel[0])
        name = self.portals[idx]["name"]
        if messagebox.askyesno("Remove", f"Remove portal '{name}'?"):
            self.portals.pop(idx)
            self.portal_name_var.set("")
            self.portal_url_var.set("")
            self._refresh_portal_list()

    # ----- per-profile tab handlers -----
    def _on_profile_select(self, _event=None) -> None:
        sel = self.profile_listbox.curselection()
        if not sel:
            return
        idx = int(sel[0])
        if 0 <= idx < len(self.profile_index):
            self._load_mapping_for(self.profile_index[idx])

    def _load_mapping_for(self, prof: ChromeProfile) -> None:
        names = self.settings.get("per_profile_portal_name", {}) or {}
        overrides = self.settings.get("per_profile_portal_override", {}) or {}
        if not isinstance(names, dict):
            names = {}
        if not isinstance(overrides, dict):
            overrides = {}
        self._current_profile = prof.dir_name
        self.per_name_var.set(str(names.get(prof.dir_name, "")))
        self.per_override_var.set(str(overrides.get(prof.dir_name, "")))

    def _save_mapping(self) -> None:
        prof = getattr(self, "_current_profile", None)
        if not prof:
            return
        name = self.per_name_var.get().strip()
        override = self.per_override_var.get().strip()

        self.settings.setdefault("per_profile_portal_name", {})
        self.settings.setdefault("per_profile_portal_override", {})
        if not isinstance(self.settings["per_profile_portal_name"], dict):
            self.settings["per_profile_portal_name"] = {}
        if not isinstance(self.settings["per_profile_portal_override"], dict):
            self.settings["per_profile_portal_override"] = {}

        if name:
            self.settings["per_profile_portal_name"][prof] = name
        else:
            self.settings["per_profile_portal_name"].pop(prof, None)

        if override:
            self.settings["per_profile_portal_override"][prof] = override
            # keep legacy in sync (override only)
            self.settings.setdefault("per_profile_portal", {})
            if isinstance(self.settings["per_profile_portal"], dict):
                self.settings["per_profile_portal"][prof] = override
        else:
            self.settings["per_profile_portal_override"].pop(prof, None)
            if isinstance(self.settings.get("per_profile_portal"), dict):
                self.settings["per_profile_portal"].pop(prof, None)

        messagebox.showinfo("Saved", "Per-profile mapping saved.")

    # ----- apply/cancel -----
    def _apply(self) -> None:
        # Save theme/accent/default portal and portals list
        self.settings.setdefault("ui", {})
        if not isinstance(self.settings["ui"], dict):
            self.settings["ui"] = {}
        self.settings["ui"]["theme"] = self.theme_var.get()
        self.settings["ui"]["accent"] = self.accent_var.get()
        self.settings["default_portal"] = self.default_portal_var.get().strip()
        self.settings["global_default_portal_name"] = self.global_default_portal_name_var.get().strip()

        self.settings.setdefault("tray", {})
        if not isinstance(self.settings["tray"], dict):
            self.settings["tray"] = {}
        self.settings["tray"]["enabled"] = bool(self.tray_enabled_var.get())

        # Apply hotkey change (validate + re-register) if requested
        if getattr(self, "_pending_hotkey", "") and str(self.settings.get("hotkey","")).strip() != str(self._pending_hotkey).strip():
            hk = str(self._pending_hotkey).strip()
            if self.set_hotkey_callback is not None:
                try:
                    ok = bool(self.set_hotkey_callback(hk))
                except Exception:
                    ok = False
                if ok:
                    self.settings["hotkey"] = hk
                else:
                    messagebox.showwarning("Hotkey", "Could not apply that hotkey. Keeping existing hotkey.")
            else:
                self.settings["hotkey"] = hk

        _set_portal_list(self.settings, self.portals)

        # call hook so app can re-theme and refresh portal dropdown
        if self.on_applied:
            try:
                self.on_applied()
            except Exception:
                pass
        self.destroy()

    def _cancel(self) -> None:
        self.destroy()
