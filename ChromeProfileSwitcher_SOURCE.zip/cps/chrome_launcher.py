import os
import shutil
import subprocess
from typing import Optional, Sequence

def find_chrome_exe() -> Optional[str]:
    # If it's on PATH
    for name in ("chrome", "chrome.exe"):
        p = shutil.which(name)
        if p:
            return p

    # Common install locations
    pf = os.environ.get("PROGRAMFILES", r"C:\Program Files")
    pf86 = os.environ.get("PROGRAMFILES(X86)", r"C:\Program Files (x86)")
    local = os.environ.get("LOCALAPPDATA")

    candidates = [
        os.path.join(pf, r"Google\Chrome\Application\chrome.exe"),
        os.path.join(pf86, r"Google\Chrome\Application\chrome.exe"),
    ]
    if local:
        candidates.append(os.path.join(local, r"Google\Chrome\Application\chrome.exe"))

    for c in candidates:
        if os.path.exists(c):
            return c
    return None

def open_profile(chrome_exe: str, profile_dir_name: str, url: Optional[str] = None) -> None:
    args = [chrome_exe, f'--profile-directory={profile_dir_name}']
    if url:
        args.append(url)
    # Detached launch; don't wait.
    subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL, close_fds=True)

