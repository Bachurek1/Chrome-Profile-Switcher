import tkinter as tk
from tkinter import ttk
from typing import Any, Dict, Optional


class DiagnosticsWindow(tk.Toplevel):
    """Small read-only diagnostics window."""

    def __init__(self, parent: tk.Misc, info: Dict[str, Any]):
        super().__init__(parent)
        self.title("Diagnostics")
        self.resizable(False, False)
        self.transient(parent)

        # Keep on top of parent but not always-on-top
        try:
            self.grab_set()
        except Exception:
            pass

        container = ttk.Frame(self)
        container.pack(fill="both", expand=True, padx=14, pady=14)

        ttk.Label(container, text="Diagnostics", style="Title.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(container, text="Copy/paste these values when reporting issues.", style="Muted.TLabel").grid(
            row=1, column=0, sticky="w", pady=(2, 10)
        )

        text = tk.Text(container, width=92, height=16, wrap="word")
        text.grid(row=2, column=0, sticky="nsew")
        text.configure(state="normal")

        def line(label: str, value: Optional[Any]) -> str:
            v = "" if value is None else str(value)
            return f"{label}: {v}\n"

        body = ""
        body += line("Chrome path", info.get("chrome_path"))
        body += line("User data path", info.get("user_data_path"))
        body += line("Local State path", info.get("local_state_path"))
        body += line("Local State last read", info.get("local_state_last_read"))
        body += line("Hotkey", info.get("hotkey_status"))
        body += line("Tray", info.get("tray_status"))
        body += line("Last launch", info.get("last_launch"))
        body += line("Last launch (masked)", info.get("last_launch_masked"))
        body += "\n"
        body += line("Tray import error", info.get("tray_import_error"))
        body += line("Tray init error", info.get("tray_error"))
        body += line("Tray init attempted", info.get("tray_init_attempted"))
        body += line("Tray init success", info.get("tray_init_success"))
        body += line("Tray HWND", info.get("tray_hwnd"))
        body += line("Tray last Win32 error", info.get("tray_last_error"))
        body += line("Tray Win32 failures", info.get("tray_win32_failures"))
        body += line("Tray start thread", info.get("tray_start_thread"))
        body += line("Tray thread", info.get("tray_thread"))

        text.insert("1.0", body)
        text.configure(state="disabled")

        btns = ttk.Frame(container)
        btns.grid(row=3, column=0, sticky="e", pady=(10, 0))

        def copy_all() -> None:
            try:
                self.clipboard_clear()
                self.clipboard_append(body)
                self.update_idletasks()
            except Exception:
                pass

        ttk.Button(btns, text="Copy", command=copy_all).pack(side="left", padx=(0, 8))
        ttk.Button(btns, text="Close", command=self.destroy).pack(side="left")