import json
import os
import re
import time
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple, Any

_PERSON_RE = re.compile(r"^Person\s+\d+\s*$", re.IGNORECASE)

# Diagnostics (best-effort)
LAST_USER_DATA_DIR: Optional[str] = None
LAST_LOCAL_STATE_PATH: Optional[str] = None
LAST_LOCAL_STATE_MTIME: float = 0.0
LAST_LOCAL_STATE_READ_TS: float = 0.0

@dataclass(frozen=True)
class ChromeProfile:
    dir_name: str          # "Default" or "Profile 1"
    display_name: str      # Chrome UI display name (best effort)
    path: str              # full path to profile directory
    email: Optional[str] = None
    gaia: Optional[str] = None

def chrome_user_data_dir() -> Optional[str]:
    local = os.environ.get("LOCALAPPDATA")
    if not local:
        return None
    candidates = [
        os.path.join(local, r"Google\Chrome\User Data"),
        os.path.join(local, r"Chromium\User Data"),
    ]
    for c in candidates:
        if os.path.isdir(c):
            global LAST_USER_DATA_DIR
            LAST_USER_DATA_DIR = c
            return c
    return None

def _safe_json_load(path: str) -> Optional[Dict[str, Any]]:
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else None
    except Exception:
        return None

def _looks_like_person_name(name: Optional[str]) -> bool:
    if not name:
        return False
    return _PERSON_RE.match(str(name).strip()) is not None

def _read_local_state(base_user_data: str) -> Tuple[Dict[str, Any], float]:
    """
    Returns (info_cache, mtime) where info_cache is Local State profile.info_cache dict.
    """
    local_state_path = os.path.join(base_user_data, "Local State")
    global LAST_LOCAL_STATE_PATH, LAST_LOCAL_STATE_MTIME, LAST_LOCAL_STATE_READ_TS
    LAST_LOCAL_STATE_PATH = local_state_path
    mtime = 0.0
    try:
        mtime = os.path.getmtime(local_state_path)
    except Exception:
        pass

    LAST_LOCAL_STATE_MTIME = mtime
    LAST_LOCAL_STATE_READ_TS = time.time()

    data = _safe_json_load(local_state_path) or {}
    info_cache = data.get("profile", {}).get("info_cache")
    if isinstance(info_cache, dict):
        return info_cache, mtime
    return {}, mtime


def get_profile_diagnostics() -> Dict[str, Any]:
    """Return best-effort diagnostics about Chrome profile discovery."""
    return {
        "user_data_dir": LAST_USER_DATA_DIR,
        "local_state_path": LAST_LOCAL_STATE_PATH,
        "local_state_mtime": LAST_LOCAL_STATE_MTIME,
        "local_state_last_read_ts": LAST_LOCAL_STATE_READ_TS,
    }

def _read_preferences(profile_path: str) -> Tuple[Dict[str, Any], float]:
    pref_path = os.path.join(profile_path, "Preferences")
    mtime = 0.0
    try:
        mtime = os.path.getmtime(pref_path)
    except Exception:
        pass
    data = _safe_json_load(pref_path) or {}
    return data, mtime

def _dir_fallback(dir_name: str) -> str:
    if dir_name == "Default":
        return "Default Profile"
    m = re.fullmatch(r"Profile (\d+)", dir_name)
    if m:
        return f"Profile {m.group(1)}"
    return dir_name

def _extract_identity(info: Dict[str, Any], pref: Dict[str, Any]) -> Tuple[Optional[str], Optional[str]]:
    """
    Best-effort extraction of email/gaia id from Local State and/or Preferences.
    This is a nice-to-have only; safe to return None.
    """
    email = None
    gaia = None

    # Local State sometimes contains user_name for signed-in profile
    if isinstance(info, dict):
        u = info.get("user_name")
        if isinstance(u, str) and "@" in u:
            email = u.strip()

        g = info.get("gaia_id")
        if isinstance(g, (str, int)):
            gaia = str(g)

    # Preferences may contain account info in various places (Chrome changes this over time)
    if isinstance(pref, dict):
        # Some builds: profile.gaia_id / profile.user_name
        p = pref.get("profile", {})
        if isinstance(p, dict):
            u = p.get("user_name")
            if not email and isinstance(u, str) and "@" in u:
                email = u.strip()
            g = p.get("gaia_id")
            if not gaia and isinstance(g, (str, int)):
                gaia = str(g)

        # Another place: account_info (list of dicts)
        ai = pref.get("account_info")
        if isinstance(ai, list) and ai:
            for item in ai:
                if not isinstance(item, dict):
                    continue
                em = item.get("email")
                if not email and isinstance(em, str) and "@" in em:
                    email = em.strip()
                gid = item.get("gaia")
                if not gaia and isinstance(gid, (str, int)):
                    gaia = str(gid)

    return email, gaia

def _resolve_display_name(dir_name: str, info: Dict[str, Any], pref: Dict[str, Any]) -> str:
    """
    Priority:
    1) Local State info_cache[dir].name (unless Person N)
    2) Local State shortcut_name (unless Person N)
    3) Preferences profile.name / profile.shortcut_name (unless Person N)
    4) name hints (gaia_name/given_name/full_name) if present
    5) directory-based fallback (never "Person N")
    """
    def _take(s: Any) -> Optional[str]:
        if isinstance(s, str) and s.strip():
            return s.strip()
        return None

    # Local State
    name = _take(info.get("name")) if isinstance(info, dict) else None
    if name and not _looks_like_person_name(name):
        return name

    sname = _take(info.get("shortcut_name")) if isinstance(info, dict) else None
    if sname and not _looks_like_person_name(sname):
        return sname

    # Preferences
    profile = pref.get("profile", {}) if isinstance(pref, dict) else {}
    if isinstance(profile, dict):
        pname = _take(profile.get("name"))
        if pname and not _looks_like_person_name(pname):
            return pname
        psname = _take(profile.get("shortcut_name"))
        if psname and not _looks_like_person_name(psname):
            return psname

        # Hints
        for k in ("gaia_name", "full_name", "given_name"):
            hint = _take(profile.get(k))
            if hint and not _looks_like_person_name(hint):
                return hint

    return _dir_fallback(dir_name)

# ---------- Cache ----------
_CACHE: Dict[str, Any] = {"fingerprint": None, "profiles": []}

def _build_fingerprint(base: str, dirs: List[str], local_state_mtime: float, pref_mtimes: Dict[str, float]) -> Tuple:
    # Only include files we care about
    return (
        base,
        int(local_state_mtime),
        tuple((d, int(pref_mtimes.get(d, 0.0))) for d in dirs),
    )

def list_profiles(force_refresh: bool = False) -> List[ChromeProfile]:
    base = chrome_user_data_dir()
    if not base:
        return []

    # discover profile directories
    profile_dirs: List[str] = []
    try:
        for name in os.listdir(base):
            full = os.path.join(base, name)
            if not os.path.isdir(full):
                continue
            if name == "Default" or re.fullmatch(r"Profile \d+", name):
                profile_dirs.append(name)
    except Exception:
        return []

    # stable ordering: Default then Profile N
    def _key(n: str) -> Tuple[int, int]:
        if n == "Default":
            return (0, 0)
        m = re.fullmatch(r"Profile (\d+)", n)
        if m:
            return (1, int(m.group(1)))
        return (2, 999999)

    profile_dirs.sort(key=_key)

    info_cache, ls_mtime = _read_local_state(base)
    pref_mtimes: Dict[str, float] = {}
    for d in profile_dirs:
        try:
            pref_mtimes[d] = os.path.getmtime(os.path.join(base, d, "Preferences"))
        except Exception:
            pref_mtimes[d] = 0.0

    fp = _build_fingerprint(base, profile_dirs, ls_mtime, pref_mtimes)

    if not force_refresh and _CACHE.get("fingerprint") == fp:
        cached = _CACHE.get("profiles")
        if isinstance(cached, list):
            return cached

    profiles: List[ChromeProfile] = []
    for dir_name in profile_dirs:
        full = os.path.join(base, dir_name)
        info = info_cache.get(dir_name, {}) if isinstance(info_cache, dict) else {}
        if not isinstance(info, dict):
            info = {}
        pref, _ = _read_preferences(full)

        display = _resolve_display_name(dir_name, info, pref)
        email, gaia = _extract_identity(info, pref)

        profiles.append(ChromeProfile(
            dir_name=dir_name,
            display_name=display,
            path=full,
            email=email,
            gaia=gaia
        ))

    _CACHE["fingerprint"] = fp
    _CACHE["profiles"] = profiles
    return profiles
