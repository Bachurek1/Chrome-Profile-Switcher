import json
import os
from typing import Any, Dict

APP_DIR_NAME = "ChromeProfileSwitcher"
SETTINGS_FILE_NAME = "settings.json"

def _settings_path() -> str:
    appdata = os.environ.get("APPDATA") or os.path.expanduser("~")
    folder = os.path.join(appdata, APP_DIR_NAME)
    os.makedirs(folder, exist_ok=True)
    return os.path.join(folder, SETTINGS_FILE_NAME)

def _deep_merge(defaults: Any, loaded: Any) -> Any:
    """
    Recursively merge loaded into defaults, preserving defaults for missing keys.
    Lists are replaced (not merged) to avoid surprising behaviour.
    """
    if isinstance(defaults, dict) and isinstance(loaded, dict):
        out = dict(defaults)
        for k, v in loaded.items():
            if k in out:
                out[k] = _deep_merge(out[k], v)
            else:
                out[k] = v
        return out
    return loaded if loaded is not None else defaults

def load_settings() -> Dict[str, Any]:
    path = _settings_path()
    defaults = default_settings()

    if not os.path.exists(path):
        return defaults

    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            return defaults

        merged = _deep_merge(defaults, data)

        # Migration: older builds used per_profile_portal only.
        # If override dict missing, seed it from per_profile_portal.
        if isinstance(merged.get("per_profile_portal"), dict) and not isinstance(merged.get("per_profile_portal_override"), dict):
            merged["per_profile_portal_override"] = dict(merged.get("per_profile_portal") or {})

        # Ensure required containers exist
        merged.setdefault("portal_urls", defaults.get("portal_urls", []))
        merged.setdefault("per_profile_portal_name", {})
        merged.setdefault("per_profile_portal_override", {})
        merged.setdefault("ui", defaults.get("ui", {}))

        return merged
    except Exception:
        return defaults

def save_settings(settings: Dict[str, Any]) -> None:
    path = _settings_path()
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(settings, f, indent=2, ensure_ascii=False)
    os.replace(tmp, path)

def default_settings() -> Dict[str, Any]:
    return {
        "ui": {
            "theme": "Dark",         # Dark | Light | Midnight | High Contrast
            "accent": "Orange",      # preset accent name
        },
        "default_portal": "https://securly.com/app",
        "global_default_portal_name": "",  # optional: name from portal_urls to use as default

        # legacy storage used by earlier modular build: profile_dir_name -> url
        "per_profile_portal": {},
        # new storage:
        "portal_urls": [
            {"name": "Securly", "url": "https://securly.com/app"},
            {"name": "Google Admin", "url": "https://admin.google.com/"},
            {"name": "Gmail", "url": "https://mail.google.com/"},
        ],
        "per_profile_portal_name": {},        # profile_dir_name -> portal name
        "per_profile_portal_override": {},    # profile_dir_name -> override url

        "favourites": [],
        "recents": [],
        "filters": {
            "favourites_only": False,
            "recent_only": False,
        },
        "hotkey": "CTRL+SHIFT+ALT+S",
        "overlay_enabled": True,
        "overlay": {
            "width": 640,
            "max_results": 12
        },
        "tray": {
            "enabled": True
        },
        "diagnostics": {
            "last_launch_command": "",
            "last_launch_masked": "",
            "last_launch_time": 0
        },
        "window": {
            "width": 980,
            "height": 560,
        }
    }